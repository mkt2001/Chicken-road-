import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useStore, init, toast } from './store';
import { setAudio, unlock } from './audio';
import { Toast } from './ui';
import Game from './game/Game';
import Auth from './screens/Auth';
import Admin from './screens/Admin';
import { Home, Modes, Rewards, Missions, Leaderboard, Shop, Vip, Profile, WalletScreen, Settings } from './screens/Menus';

export default function App() {
  const { ready, state: s, needAuth, toast: t, offline } = useStore();
  const [scr, setScr] = useState<any>({ name: 'home', arg: null }); const [loadPct, setLoadPct] = useState(0);
  useEffect(() => { init(); const iv = setInterval(() => setLoadPct((p) => Math.min(100, p + 8)), 90); return () => clearInterval(iv); }, []);
  useEffect(() => { const f = () => unlock(); window.addEventListener('pointerdown', f); return () => window.removeEventListener('pointerdown', f); }, []);
  useEffect(() => { if (s) setAudio({ music: s.settings.music, sfx: s.settings.sfx, vol: s.settings.vol, pack: s.eq.sfx.split('_')[1] }); }, [s && s.settings, s && s.eq.sfx]);
  useEffect(() => { if (offline) toast('Offline: menus work, play needs the server', 'info'); }, [offline]);
  useEffect(() => { if (location.hash === '#/admin') setScr({ name: 'admin', arg: null }); }, [ready]);
  const go = (name: string, arg: any = null) => setScr({ name, arg });
  const home = () => go('home');

  if (!ready || loadPct < 100) return (
    <div className="bg-dusk absolute inset-0 flex flex-col items-center justify-center gap-4">
      <div className="text-8xl floaty">🐔</div><div className="text-3xl font-black gold-text">CHICKEN ROAD</div>
      <div className="h-3 w-56 overflow-hidden rounded-full bg-white/15"><motion.div className="h-full bg-gradient-to-r from-yellow-300 to-orange-500" style={{ width: `${loadPct}%` }} /></div>
      <div className="text-xs text-white/50">Loading road…</div>
    </div>);
  if (needAuth || !s) return <><Auth /><Toast t={t} /></>;
  const bg = 'bg-' + s.eq.bg.split('_')[1];
  const P: any = { home: <Home go={go} />, modes: <Modes go={go} back={home} />, rewards: <Rewards back={home} />, missions: <Missions back={home} />, leaderboard: <Leaderboard back={home} />, shop: <Shop back={home} />, vip: <Vip back={home} />, profile: <Profile back={home} />, wallet: <WalletScreen back={home} />, settings: <Settings back={home} go={go} />, admin: <Admin back={home} /> };
  return (
    <div className="absolute inset-0">
      {scr.name === 'game' ? <Game key={scr.arg} mode={scr.arg} onExit={home} /> : (
        <div className={`${bg} absolute inset-0 overflow-hidden`}><AnimatePresence mode="wait"><div key={scr.name} className="absolute inset-0">{P[scr.name]}</div></AnimatePresence></div>)}
      <Toast t={t} />
    </div>
  );
}
