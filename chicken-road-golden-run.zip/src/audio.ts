// Procedural sound system (WebAudio) – no audio files needed, works offline.
let ctx: any = null, master: any = null, musicTimer: any = null, noteIdx = 0;
const cfg: any = { music: true, sfx: true, vol: 0.7, pack: 'classic' };
const WAVE: any = { classic: 'triangle', arcade: 'square', soft: 'sine' };
const SCALE = [261.6, 311.1, 392, 466.2, 523.3, 392, 349.2, 311.1];
export function unlock() {
  if (!ctx) {
    const AC = (window as any).AudioContext || (window as any).webkitAudioContext; if (!AC) return;
    ctx = new AC(); master = ctx.createGain(); master.gain.value = cfg.vol; master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  syncMusic();
}
export function setAudio(o: any) {
  Object.assign(cfg, o); if (master) master.gain.value = cfg.vol; syncMusic();
}
function syncMusic() {
  if (!ctx) return;
  if (cfg.music && !musicTimer) {
    musicTimer = setInterval(() => { const f = SCALE[noteIdx++ % SCALE.length] * (noteIdx % 16 < 8 ? 1 : 0.75); tone(f, 0.35, 'triangle', 0.05, 0, 0, true); if (noteIdx % 4 === 0) tone(f / 2, 0.5, 'sine', 0.06, 0, 0, true); }, 280);
  } else if (!cfg.music && musicTimer) { clearInterval(musicTimer); musicTimer = null; }
}
function tone(f: number, dur: number, type: string, vol: number, delay = 0, slide = 0, isMusic = false) {
  if (!ctx || (!isMusic && !cfg.sfx)) return;
  const t = ctx.currentTime + delay, o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.02);
}
function noise(dur: number, vol: number, freq: number) {
  if (!ctx || !cfg.sfx) return;
  const n = Math.floor(ctx.sampleRate * dur), buf = ctx.createBuffer(1, n, ctx.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
  const s = ctx.createBufferSource(); s.buffer = buf; const fl = ctx.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = freq;
  const g = ctx.createGain(); g.gain.value = vol; s.connect(fl); fl.connect(g); g.connect(master); s.start();
}
const w = () => WAVE[cfg.pack] || 'triangle';
export const sfx = {
  click() { tone(660, 0.07, w(), 0.12); },
  step() { tone(300, 0.12, w(), 0.15, 0, 200); tone(520, 0.1, w(), 0.1, 0.06); },
  chicken() { tone(900, 0.08, 'square', 0.07, 0, 300); tone(1100, 0.08, 'square', 0.06, 0.09, -200); },
  unlock(m = 1) { const b = 440 + Math.min(m, 50) * 8; tone(b, 0.12, w(), 0.14); tone(b * 1.25, 0.12, w(), 0.14, 0.08); tone(b * 1.5, 0.2, w(), 0.14, 0.16); },
  coin() { tone(1200, 0.08, 'square', 0.08); tone(1800, 0.16, 'square', 0.08, 0.07); },
  win() { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, 0.22, w(), 0.16, i * 0.09)); },
  hit() { noise(0.45, 0.5, 700); tone(160, 0.4, 'sawtooth', 0.18, 0, -110); },
  car() { noise(0.5, 0.18, 400); },
};
