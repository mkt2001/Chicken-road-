import { useSyncExternalStore } from 'react';
import { DEFAULT_CONFIG } from '../shared/config.js';
import { newState, act as runAct } from '../shared/service.js';
import { secureRandom } from '../shared/engine.js';

const ENV: any = (import.meta as any).env || {};
const API: string = ENV.VITE_API_URL || '';
export const REMOTE: boolean = ENV.VITE_REMOTE === '1' || ENV.VITE_REMOTE === 'true' || !!API;
export const GOOGLE_ID: string = ENV.VITE_GOOGLE_CLIENT_ID || '';
const ls = {
  get(k: string) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k: string, v: string) { try { localStorage.setItem(k, v); } catch (e) { /* storage full or blocked */ } },
  del(k: string) { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } },
};
let snap: any = { cfg: DEFAULT_CONFIG, state: null, user: null, token: ls.get('cr_token') || '', ready: false, needAuth: false, offline: false, toast: null };
const subs = new Set<() => void>();
const emit = () => { snap = { ...snap }; subs.forEach((f) => f()); };
export const getSnap = () => snap;
export const useStore = () => useSyncExternalStore((cb) => { subs.add(cb); return () => { subs.delete(cb); }; }, () => snap);

let toastTimer: any;
export function toast(msg: string, kind = 'info') {
  snap.toast = { msg, kind, id: Date.now() }; emit(); clearTimeout(toastTimer); toastTimer = setTimeout(() => { snap.toast = null; emit(); }, 2600);
}
const cache = (st: any) => ls.set(REMOTE ? 'cr_cache_remote' : 'cr_state', JSON.stringify(st));

async function http(path: string, method = 'GET', body?: any) {
  const res = await fetch(API + path, { method, headers: { 'Content-Type': 'application/json', ...(snap.token ? { Authorization: 'Bearer ' + snap.token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  let j: any = {}; try { j = await res.json(); } catch (e) { /* no body */ }
  if (res.status === 401 && snap.token) { logout(true); }
  return j;
}
export async function api(path: string, method = 'GET', body?: any) {
  try { return await http(path, method, body); } catch (e) { return { ok: false, error: 'Cannot reach the server' }; }
}
function applySession(j: any) {
  snap.token = j.token || snap.token; if (j.token) ls.set('cr_token', j.token);
  snap.user = j.user; snap.state = j.state; if (j.config) { snap.cfg = j.config; ls.set('cr_cfg', JSON.stringify(j.config)); }
  snap.needAuth = false; snap.offline = false; cache(j.state); emit();
}
export async function init() {
  if (!REMOTE) {
    let st: any = null; try { st = JSON.parse(ls.get('cr_state') || 'null'); } catch (e) { st = null; }
    if (!st || !st.eq) st = newState(snap.cfg, 'Player');
    snap.state = st; snap.ready = true; emit(); return;
  }
  try { const c = JSON.parse(ls.get('cr_cfg') || 'null'); if (c) snap.cfg = c; } catch (e) { /* ignore */ }
  if (snap.token) {
    const j = await api('/api/me');
    if (j.ok) { applySession(j); snap.ready = true; emit(); return; }
    if (j.error === 'Cannot reach the server') {
      try { const st = JSON.parse(ls.get('cr_cache_remote') || 'null'); if (st) { snap.state = st; snap.offline = true; snap.ready = true; emit(); return; } } catch (e) { /* ignore */ }
    }
  }
  snap.needAuth = true; snap.ready = true; emit();
}
export async function guestLogin() {
  let dev = ls.get('cr_device'); if (!dev) { dev = 'dev-' + Math.random().toString(36).slice(2) + Date.now().toString(36); ls.set('cr_device', dev); }
  const j = await api('/api/auth/guest', 'POST', { deviceId: dev }); if (j.ok) applySession(j); return j;
}
export async function emailAuth(mode: string, email: string, password: string, name: string) {
  const j = await api('/api/auth/' + mode, 'POST', { email, password, name }); if (j.ok) applySession(j); return j;
}
export async function googleLogin(idToken: string) { const j = await api('/api/auth/google', 'POST', { idToken }); if (j.ok) applySession(j); return j; }
export function logout(expired = false) {
  ls.del('cr_token'); ls.del('cr_cache_remote'); snap.token = ''; snap.user = null; snap.state = null; snap.needAuth = true; emit();
  if (expired) toast('Session expired, please log in again', 'error');
}
export async function doAct(name: string, args: any = {}) {
  if (!snap.state) return { ok: false, error: 'Not ready' };
  if (REMOTE) {
    if (snap.offline) { const j = await api('/api/me'); if (j.ok) applySession(j); else return { ok: false, error: 'Server connection required' }; }
    const j = await api('/api/act', 'POST', { name, args });
    if (j.state) { snap.state = j.state; cache(j.state); emit(); }
    return j;
  }
  const s = JSON.parse(JSON.stringify(snap.state));
  const r = runAct(s, snap.cfg, secureRandom, name, args, Date.now());
  snap.state = s; cache(s); emit(); return r;
}
export function resetLocal() { ls.del('cr_state'); snap.state = newState(snap.cfg, 'Player'); cache(snap.state); emit(); }
