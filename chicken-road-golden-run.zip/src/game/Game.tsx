import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Scene from './Scene';
import { useStore, doAct, toast } from '../store';
import { multTable, hazard, difficultyScore } from '../../shared/engine.js';
import { dailyLevel } from '../../shared/service.js';
import { Btn, Wallet, Modal, fmt, fmtM } from '../ui';
import { sfx, unlock } from '../audio';

const isMobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || (navigator.hardwareConcurrency || 8) <= 4;

export default function Game({ mode: modeProp, onExit }: any) {
  const { state: s, cfg } = useStore();
  const active = s.round && s.round.status === 'active' ? s.round : null;
  const mode = active ? active.mode : modeProp;
  const m = cfg.modes[mode];
  const [level, setLevel] = useState(Math.max(m.minLevel, Math.min(3, 10)));
  const [stake, setStake] = useState(Math.min(100, Math.max(cfg.minStake, s.gold)));
  const [cmd, setCmd] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [low, setLow] = useState(false);
  const [left, setLeft] = useState(0);
  const cid = useRef(0), pending = useRef<any>(null);
  const lvl = mode === 'daily' ? dailyLevel(cfg, Date.now()) : Math.max(level, m.minLevel);
  const r = s.round && s.round.mode === mode ? s.round : { lanes: m.lanes, level: lvl, seed: 7, step: 0, status: 'idle', mode, stake: 0, mult: 1 };
  const table = useMemo(() => multTable(cfg, r.level, mode, r.lanes), [cfg, r.level, mode, r.lanes]);
  const q = s.settings.quality === 'auto' ? (low ? 0 : isMobile ? 1 : 2) : { low: 0, medium: 1, high: 2 }[s.settings.quality as string];
  const dName = cfg.difficulties[r.level - 1].name, score = difficultyScore(cfg, r.level);

  useEffect(() => { setCmd({ id: ++cid.current, type: 'place', to: active ? active.step : 0 }); /* eslint-disable-next-line */ }, []);
  useEffect(() => {
    if (!active || !active.deadline) { setLeft(0); return; }
    const t = setInterval(async () => {
      const l = Math.max(0, active.deadline - Date.now()); setLeft(l);
      if (l <= 0 && !pending.current?.busy) { clearInterval(t); const res = await doAct('expire'); if (res.ok) { setBusy(false); setResult(res.round); sfx.hit(); } }
    }, 250);
    return () => clearInterval(t);
  }, [active && active.id]);

  async function start() {
    unlock(); setResult(null); await doAct('clearRound');
    const res = await doAct('startRound', { stake, mode, level: lvl });
    if (!res.ok) { toast(res.error, 'error'); return; }
    setCmd({ id: ++cid.current, type: 'place', to: 0 }); sfx.click();
  }
  async function go() {
    if (busy || !active) return; setBusy(true); unlock(); sfx.step(); sfx.chicken();
    const from = active.step, res = await doAct('stepRound');
    if (!res.ok) { toast(res.error, 'error'); setBusy(false); return; }
    pending.current = res;
    if (res.timeout) { setBusy(false); setResult(res.round); sfx.hit(); return; }
    if (res.hit) { sfx.car(); setTimeout(() => sfx.hit(), 480); }
    setCmd({ id: ++cid.current, type: 'hop', to: from + 1, hit: !!res.hit });
  }
  function onDone(kind: string) {
    const res = pending.current; if (!res) return;
    if (kind === 'hit') { setResult(res.round); setBusy(false); return; }
    sfx.unlock(res.round.mult);
    if (res.done) { sfx.win(); setCmd({ id: ++cid.current, type: 'win' }); setResult(res.round); } else setBusy(false);
  }
  async function cash() {
    if (busy || !active || active.step < 1) return; setBusy(true);
    const res = await doAct('cashout'); setBusy(false);
    if (!res.ok) { toast(res.error, 'error'); return; }
    if (res.timeout) { setResult(res.round); sfx.hit(); return; }
    sfx.win(); sfx.coin(); setCmd({ id: ++cid.current, type: 'win' }); setResult(res.round);
  }
  async function again() { setResult(null); await start(); }
  const clampStake = (v: number) => Math.max(cfg.minStake, Math.min(Math.floor(v) || cfg.minStake, cfg.maxStake, Math.max(s.gold, cfg.minStake)));
  const nextHaz = active ? hazard(cfg, r.level, r.step, mode) : hazard(cfg, r.level, 0, mode);
  const reward = active ? Math.floor(active.stake * active.mult) : 0;
  const nextMult = table[Math.min(r.step, r.lanes - 1)];
  const eq = s.eq, key = (id: string) => id.split('_')[1];

  return (
    <div className="fixed inset-0">
      <Scene cmd={cmd} round={r} table={table} cfgDiff={cfg.difficulties} skin={key(eq.skin)} env={key(eq.road)} anim={key(eq.anim)} fx={key(eq.fx)} quality={q} onDone={onDone} onLow={() => setLow(true)} />
      <div className="pointer-events-none absolute inset-0 flex flex-col justify-between">
        <div className="safe-top flex items-center justify-between gap-2 px-3">
          <div className="pointer-events-auto"><Btn kind="dark" className="!px-3 !py-2" disabled={busy} onClick={onExit}>←</Btn></div>
          <div className="glass px-3 py-1 text-center text-xs font-bold leading-tight">{m.icon} {m.name}<br /><span className="text-yellow-300">Lv{r.level} {dName}</span></div>
          <Wallet s={s} />
        </div>

        {active && (
          <div className="pointer-events-none px-4 text-center" style={{ marginBottom: '38vh' }}>
            <div className="glass mx-auto inline-block px-5 py-2">
              <motion.div key={active.mult} initial={{ scale: 1.5 }} animate={{ scale: 1 }} className="text-4xl font-black gold-text">{active.step ? fmtM(active.mult) : '1.00x'}</motion.div>
              <div className="text-sm font-bold text-emerald-300">Reward 🪙 {fmt(reward)}</div>
              <div className="text-xs text-white/70">Next {fmtM(nextMult)} · Risk <span className={nextHaz > 0.5 ? 'text-red-400' : nextHaz > 0.25 ? 'text-orange-300' : 'text-emerald-300'}>{Math.round(nextHaz * 100)}%</span>{left > 0 && <span className="ml-2 font-black text-red-300">⏱ {Math.ceil(left / 1000)}s</span>}</div>
            </div>
          </div>
        )}

        <div className="pointer-events-auto safe-bot px-3">
          {active ? (
            <div className="flex gap-3">
              <Btn kind="green" className="flex-1 !py-4 text-lg" disabled={busy || active.step < 1} onClick={cash}>CASH OUT<br /><span className="text-sm">🪙 {fmt(reward)}</span></Btn>
              <Btn kind="gold" className="flex-1 !py-4 text-xl" disabled={busy || active.step >= active.lanes} onClick={go}>GO ▶<br /><span className="text-sm">{active.step}/{active.lanes}</span></Btn>
            </div>
          ) : !result && (
            <div className="glass p-3">
              <div className="mb-2 flex items-center gap-2">
                <Btn kind="dark" className="!px-3 !py-1" onClick={() => setStake(clampStake(stake / 2))}>½</Btn>
                <input value={stake} inputMode="numeric" onChange={(e) => setStake(clampStake(Number(e.target.value.replace(/\D/g, ''))))} className="min-w-0 flex-1 rounded-xl bg-black/40 px-3 py-2 text-center text-xl font-black text-yellow-300 outline-none" />
                <Btn kind="dark" className="!px-3 !py-1" onClick={() => setStake(clampStake(stake * 2))}>2×</Btn>
                <Btn kind="dark" className="!px-3 !py-1" onClick={() => setStake(clampStake(s.gold))}>MAX</Btn>
              </div>
              <div className="mb-2 flex gap-1">{[10, 100, 500, 1000, 5000].map((v) => <Btn key={v} kind="dark" className="flex-1 !px-1 !py-1 text-sm" onClick={() => setStake(clampStake(v))}>{v}</Btn>)}</div>
              {mode !== 'daily' ? (
                <div className="mb-2 flex gap-1 overflow-x-auto pb-1">{cfg.difficulties.map((d: any, i: number) => (
                  <button key={i} disabled={i + 1 < m.minLevel} onClick={() => { sfx.click(); setLevel(i + 1); }} className={`min-w-[38px] rounded-lg px-2 py-1 text-sm font-black ${level === i + 1 ? 'btn-purple' : 'btn-dark'} ${i + 1 < m.minLevel ? 'opacity-30' : ''}`}>{i + 1}</button>))}</div>
              ) : <div className="mb-2 text-center text-xs text-yellow-300">Today's level is fixed: {dName}</div>}
              <div className="mb-2 flex items-center gap-2 text-xs"><span className="w-20 font-bold">{dName}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-yellow-400 to-red-500" style={{ width: `${Math.round(score * 100)}%` }} /></div>
                <span className="w-24 text-right text-white/80">Max {fmtM(table[table.length - 1])}</span></div>
              <Btn kind="gold" className="w-full !py-3 text-lg" disabled={s.gold < cfg.minStake} onClick={start}>{s.gold < cfg.minStake ? 'Not enough coins' : `START · 🪙 ${fmt(stake)}`}</Btn>
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {result && (
          <Modal>
            {result.status === 'cashed' ? (
              <div className="text-center">
                <div className="text-5xl floaty">🏆</div>
                <div className="mt-1 text-2xl font-black gold-text">YOU WIN!</div>
                <div className="mt-2 text-4xl font-black text-emerald-300">+🪙 {fmt(result.payout)}</div>
                <div className="text-sm text-white/80">{fmtM(result.mult)} · Net profit {result.profit >= 0 ? '+' : ''}{fmt(result.profit)}</div>
                {result.bonus && (result.bonus.diamonds || result.bonus.gold) && <div className="mt-1 text-sm text-cyan-300">Bonus: {result.bonus.gold ? `🪙 ${result.bonus.gold} ` : ''}{result.bonus.diamonds ? `💎 ${result.bonus.diamonds}` : ''}</div>}
              </div>
            ) : (
              <div className="text-center">
                <div className="text-5xl">💥</div>
                <div className="mt-1 text-2xl font-black text-red-400">{result.status === 'timeout' ? "TIME'S UP!" : 'HIT BY TRAFFIC!'}</div>
                <div className="mt-2 text-3xl font-black text-red-300">-🪙 {fmt(result.stake)}</div>
                <div className="text-sm text-white/80">Lost at lane {result.step + 1} of {result.lanes}</div>
              </div>
            )}
            <div className="mt-4 flex gap-2">
              <Btn kind="dark" className="flex-1" onClick={() => { setResult(null); doAct('clearRound'); onExit(); }}>Home</Btn>
              <Btn kind="gold" className="flex-1" disabled={s.gold < cfg.minStake} onClick={again}>Play Again</Btn>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  );
}
