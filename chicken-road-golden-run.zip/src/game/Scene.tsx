import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { lanePattern } from '../../shared/engine.js';

export const LW = 3.2;
export const laneX = (k: number) => k * LW;
const TILE_COLORS = ['#a855f7', '#22d3ee', '#f59e0b', '#ec4899', '#22c55e', '#ef4444', '#eab308', '#6366f1'];

export const SKINS: any = {
  classic: { body: '#ffffff', wing: '#eeeeee', comb: '#e53935', beak: '#ffb300', metal: 0, rough: 0.7, emi: '#000000', ei: 0 },
  golden: { body: '#ffcc33', wing: '#ffb300', comb: '#ff6f00', beak: '#fff176', metal: 0.9, rough: 0.25, emi: '#4d3300', ei: 0.5 },
  neon: { body: '#12121c', wing: '#1b1b2f', comb: '#ff00e6', beak: '#00ffe1', metal: 0.3, rough: 0.3, emi: '#00ffe1', ei: 0.7 },
  robot: { body: '#9fb0c0', wing: '#6c7a89', comb: '#ff1744', beak: '#ffd600', metal: 0.9, rough: 0.3, emi: '#000000', ei: 0, extra: 'antenna' },
  royal: { body: '#fff8e1', wing: '#ffe0b2', comb: '#b71c1c', beak: '#ffa000', metal: 0.1, rough: 0.5, emi: '#000000', ei: 0, extra: 'crown' },
  fire: { body: '#ff7043', wing: '#ff3d00', comb: '#ffeb3b', beak: '#ffeb3b', metal: 0.1, rough: 0.5, emi: '#ff3d00', ei: 0.6 },
  diamond: { body: '#b3ecff', wing: '#80d8ff', comb: '#e1f5fe', beak: '#ffffff', metal: 0.95, rough: 0.05, emi: '#33bbff', ei: 0.35 },
  phantom: { body: '#7e57c2', wing: '#5e35b1', comb: '#ea80fc', beak: '#ea80fc', metal: 0.4, rough: 0.3, emi: '#b388ff', ei: 0.8, extra: 'halo' },
  cosmic: { body: '#1a237e', wing: '#311b92', comb: '#ffea00', beak: '#ffea00', metal: 0.6, rough: 0.2, emi: '#e040fb', ei: 0.8, extra: 'halo' },
};
export const ENVS: any = {
  city: { sky: '#7fb8ff', ground: '#4f5b4a', road: '#3a3d46', road2: '#42454f', walk: '#9aa0a6', amb: 0.7, sun: 1.1, decor: 'building' },
  highway: { sky: '#8fc9ff', ground: '#6b7a55', road: '#2f3138', road2: '#383a42', walk: '#b0b4b8', amb: 0.75, sun: 1.2, decor: 'pole' },
  village: { sky: '#9ad9ff', ground: '#5fa24a', road: '#7a6a55', road2: '#85755f', walk: '#bda98a', amb: 0.8, sun: 1.1, decor: 'tree' },
  night: { sky: '#0a0f2a', ground: '#12192b', road: '#20232d', road2: '#262a36', walk: '#4a5060', amb: 0.28, sun: 0.35, decor: 'lamp', lamp: true },
  rain: { sky: '#5b6a7c', ground: '#3b4a45', road: '#2c3038', road2: '#333843', walk: '#7d8791', amb: 0.5, sun: 0.5, decor: 'building', rain: true },
  desert: { sky: '#ffcf8a', ground: '#d9a05b', road: '#5c5147', road2: '#665a50', walk: '#e6c58f', amb: 0.85, sun: 1.3, decor: 'cactus' },
  snow: { sky: '#cfe3f5', ground: '#f2f7fb', road: '#5a6270', road2: '#626a78', walk: '#dfe9f2', amb: 0.85, sun: 1, decor: 'pine', snow: true },
};
const FXC: any = { sparkle: '#ffd54f', fire: '#ff6d00', neon: '#00e5ff', stars: '#ff4081' };

function Wheels({ z0, z1, w = 0.65 }: any) {
  return <>{[[-w, z0], [w, z0], [-w, z1], [w, z1]].map((p: any, i) => (
    <mesh key={i} position={[p[0], 0.28, p[1]]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.3, 0.3, 0.22, 10]} /><meshLambertMaterial color="#111" /></mesh>))}</>;
}
function Lamps({ z, y = 0.55, w = 0.4 }: any) {
  return <>{[-w, w].map((x) => <mesh key={x} position={[x, y, z]}><boxGeometry args={[0.22, 0.14, 0.05]} /><meshLambertMaterial color="#fff6b0" emissive="#fff6b0" emissiveIntensity={1.5} /></mesh>)}</>;
}
export function Vehicle({ type, hue, color }: any) {
  const c = color || `hsl(${hue || 0},70%,50%)`;
  if (type === 'truck') return (
    <group>
      <mesh position={[0, 1.0, -0.9]} castShadow><boxGeometry args={[1.4, 1.5, 3.2]} /><meshLambertMaterial color="#cfd8dc" /></mesh>
      <mesh position={[0, 0.8, 1.35]} castShadow><boxGeometry args={[1.4, 1.2, 1.3]} /><meshLambertMaterial color={c} /></mesh>
      <mesh position={[0, 1.15, 2.01]}><boxGeometry args={[1.1, 0.5, 0.05]} /><meshLambertMaterial color="#223" /></mesh>
      <Wheels z0={-1.8} z1={1.4} w={0.7} /><Lamps z={2.02} y={0.5} w={0.5} />
    </group>);
  if (type === 'bus') return (
    <group>
      <mesh position={[0, 1.0, 0]} castShadow><boxGeometry args={[1.5, 1.6, 4.6]} /><meshLambertMaterial color={c} /></mesh>
      <mesh position={[0, 1.35, 0]}><boxGeometry args={[1.54, 0.5, 4.1]} /><meshLambertMaterial color="#1b2a3a" /></mesh>
      <Wheels z0={-1.5} z1={1.5} w={0.72} /><Lamps z={2.31} y={0.5} w={0.5} />
    </group>);
  if (type === 'bike') return (
    <group>
      <mesh position={[0, 0.55, 0]} castShadow><boxGeometry args={[0.35, 0.45, 1.2]} /><meshLambertMaterial color={c} /></mesh>
      <mesh position={[0, 1.1, -0.1]}><sphereGeometry args={[0.28, 10, 10]} /><meshLambertMaterial color="#222" /></mesh>
      <mesh position={[0, 0.3, 0.55]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.3, 0.3, 0.12, 10]} /><meshLambertMaterial color="#111" /></mesh>
      <mesh position={[0, 0.3, -0.55]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.3, 0.3, 0.12, 10]} /><meshLambertMaterial color="#111" /></mesh>
      <Lamps z={0.62} y={0.75} w={0.08} />
    </group>);
  return (
    <group>
      <mesh position={[0, 0.55, 0]} castShadow><boxGeometry args={[1.2, 0.55, 2.3]} /><meshLambertMaterial color={c} /></mesh>
      <mesh position={[0, 0.98, -0.1]} castShadow><boxGeometry args={[1.0, 0.45, 1.2]} /><meshLambertMaterial color="#1b2a3a" /></mesh>
      <Wheels z0={-0.8} z1={0.8} /><Lamps z={1.16} />
    </group>);
}

function Chicken({ G, skin }: any) {
  const grp = useRef<any>(), lL = useRef<any>(), lR = useRef<any>(), wL = useRef<any>(), wR = useRef<any>();
  const sk = SKINS[skin] || SKINS.classic;
  useFrame((_, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05), g = grp.current; if (!g) return;
    G.clock += dt; let y = 0, rx = 0, ry = 0, rz = 0, swing = 0, flap = 0.1;
    if (G.phase === 'idle') { y = Math.sin(G.clock * 3) * 0.04; flap = Math.sin(G.clock * 2) * 0.05; }
    else if (G.phase === 'hop') {
      G.t += dt; const e = Math.min(1, G.t / G.D); G.x = G.from + (G.to - G.from) * e; y = Math.sin(Math.PI * e) * 1.3;
      swing = Math.sin(G.clock * 30) * 0.9; flap = Math.sin(G.clock * 40) * 0.8;
      if (G.anim === 'flip') rz = -e * Math.PI * 2; if (G.anim === 'spin') ry = e * Math.PI * 2;
      if (e >= 1) {
        G.x = G.to;
        if (G.hit) { G.phase = 'hit'; G.t = 0; G.px = 0; G.py = 0; G.pz = 0; G.vy = 9; G.vz = 13; }
        else { G.phase = 'idle'; G.burst = 1; G.onDone && G.onDone('safe'); }
      }
    } else if (G.phase === 'hit') {
      G.t += dt; G.vy -= 26 * dt; G.py = Math.max(0, G.py + G.vy * dt); G.pz += G.vz * dt * (G.py > 0 ? 1 : 0.2);
      if (G.py === 0) G.vy = 0; rx = Math.min(G.t * 12, Math.PI / 2); ry = G.t * 6; y = G.py; flap = 1;
      if (G.t > 1.4 && !G.reported) { G.reported = true; G.onDone && G.onDone('hit'); }
    } else if (G.phase === 'win') {
      y = Math.abs(Math.sin(G.clock * 7)) * 0.9; ry = G.clock * 5; swing = Math.sin(G.clock * 20) * 0.5; flap = Math.sin(G.clock * 25);
    }
    g.position.set(G.x + (G.phase === 'hit' ? G.px : 0), y, G.phase === 'hit' ? G.pz : 0);
    g.rotation.set(rx, ry, rz);
    if (lL.current) { lL.current.rotation.z = swing; lR.current.rotation.z = -swing; }
    if (wL.current) { wL.current.rotation.x = flap; wR.current.rotation.x = -flap; }
  });
  const M = (c: string) => <meshLambertMaterial color={c} emissive={sk.emi} emissiveIntensity={sk.ei} />;
  return (
    <group ref={grp} scale={1.15}>
      <mesh position={[0, 0.62, 0]} scale={[1, 0.88, 0.8]} castShadow><sphereGeometry args={[0.5, 18, 14]} />{M(sk.body)}</mesh>
      <mesh position={[0.42, 1.18, 0]} castShadow><sphereGeometry args={[0.28, 14, 12]} />{M(sk.body)}</mesh>
      <mesh position={[0.7, 1.12, 0]} rotation={[0, 0, -Math.PI / 2]}><coneGeometry args={[0.1, 0.26, 8]} /><meshLambertMaterial color={sk.beak} /></mesh>
      {[-0.08, 0.04, 0.16].map((dx, i) => <mesh key={i} position={[0.4 + dx - 0.05, 1.5 - Math.abs(dx) * 0.4, 0]}><boxGeometry args={[0.1, 0.16, 0.08]} /><meshLambertMaterial color={sk.comb} /></mesh>)}
      <mesh position={[0.64, 1.22, 0.14]}><sphereGeometry args={[0.05, 8, 8]} /><meshBasicMaterial color="#111" /></mesh>
      <mesh position={[0.64, 1.22, -0.14]}><sphereGeometry args={[0.05, 8, 8]} /><meshBasicMaterial color="#111" /></mesh>
      <mesh position={[0.66, 0.98, 0]}><sphereGeometry args={[0.06, 8, 8]} /><meshLambertMaterial color="#e53935" /></mesh>
      <group ref={wL} position={[0, 0.7, 0.4]}><mesh position={[-0.1, 0, 0.05]} scale={[1, 0.6, 0.25]}><sphereGeometry args={[0.32, 10, 8]} />{M(sk.wing)}</mesh></group>
      <group ref={wR} position={[0, 0.7, -0.4]}><mesh position={[-0.1, 0, -0.05]} scale={[1, 0.6, 0.25]}><sphereGeometry args={[0.32, 10, 8]} />{M(sk.wing)}</mesh></group>
      <mesh position={[-0.5, 0.9, 0]} rotation={[0, 0, 0.6]}><boxGeometry args={[0.35, 0.4, 0.14]} />{M(sk.wing)}</mesh>
      <group ref={lL} position={[0, 0.2, 0.17]}><mesh position={[0, -0.02, 0]}><cylinderGeometry args={[0.035, 0.035, 0.36, 6]} /><meshLambertMaterial color="#ff9800" /></mesh><mesh position={[0.07, -0.2, 0]}><boxGeometry args={[0.2, 0.04, 0.12]} /><meshLambertMaterial color="#ff9800" /></mesh></group>
      <group ref={lR} position={[0, 0.2, -0.17]}><mesh position={[0, -0.02, 0]}><cylinderGeometry args={[0.035, 0.035, 0.36, 6]} /><meshLambertMaterial color="#ff9800" /></mesh><mesh position={[0.07, -0.2, 0]}><boxGeometry args={[0.2, 0.04, 0.12]} /><meshLambertMaterial color="#ff9800" /></mesh></group>
      {sk.extra === 'crown' && <mesh position={[0.4, 1.62, 0]}><cylinderGeometry args={[0.2, 0.15, 0.18, 5]} /><meshLambertMaterial color="#ffd700" emissive="#ffb300" emissiveIntensity={0.5} /></mesh>}
      {sk.extra === 'antenna' && <mesh position={[0.4, 1.65, 0]}><cylinderGeometry args={[0.02, 0.02, 0.35, 6]} /><meshLambertMaterial color="#ff1744" emissive="#ff1744" emissiveIntensity={1} /></mesh>}
      {sk.extra === 'halo' && <mesh position={[0.4, 1.7, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[0.24, 0.03, 8, 20]} /><meshBasicMaterial color="#fffde7" /></mesh>}
    </group>
  );
}

function Killer({ G }: any) {
  const ref = useRef<any>();
  useFrame((_, dt) => {
    const g = ref.current; if (!g) return; const k = G.killer;
    if (!k || !k.on) { g.visible = false; return; }
    k.t += Math.min(dt, 0.05); const z = -18 + k.t * (18 / k.D);
    g.visible = z < 30; g.position.set(laneX(k.lane), 0.1, z);
  });
  return <group ref={ref} visible={false}><Vehicle type="truck" color="#e11d48" /></group>;
}

function Lane({ k, G, pat }: any) {
  const g = useRef<any>();
  useFrame(() => {
    const grp = g.current; if (!grp) return; const t = G.clock, active = G.lane === k || (G.killer && G.killer.lane === k);
    grp.children.forEach((c: any, i: number) => {
      const v = pat.vehicles[i]; if (!v) return;
      const z = (((v.off + t * pat.speed) % pat.period) + pat.period) % pat.period - pat.period / 2, zz = pat.dir * z;
      c.position.set(Math.sin(t * 1.3 + i) * pat.moving * 0.25, 0, zz); c.rotation.y = pat.dir > 0 ? 0 : Math.PI;
      c.visible = !(active && Math.abs(zz) < 2.8);
    });
  });
  return <group ref={g} position={[laneX(k), 0.1, 0]}>{pat.vehicles.map((v: any, i: number) => <group key={i}><Vehicle type={v.type} hue={v.hue} /></group>)}</group>;
}

function Decor({ kind, x, side, s }: any) {
  const z = side * (13 + (s % 3));
  if (kind === 'building') { const h = 4 + (s % 7) * 1.6; return <group position={[x, 0, z]}><mesh position={[0, h / 2, 0]} castShadow><boxGeometry args={[3.4, h, 3.4]} /><meshLambertMaterial color={['#8d99ae', '#6c7a89', '#a4745a', '#7f8fa6'][s % 4]} /></mesh><mesh position={[0, h / 2, -side * 1.72]}><boxGeometry args={[2.6, h * 0.8, 0.05]} /><meshLambertMaterial color="#ffe9a0" emissive="#ffd54f" emissiveIntensity={0.35} /></mesh></group>; }
  if (kind === 'tree') return <group position={[x, 0, z - 4]}><mesh position={[0, 0.8, 0]} castShadow><cylinderGeometry args={[0.25, 0.3, 1.6, 7]} /><meshLambertMaterial color="#7a4b2a" /></mesh><mesh position={[0, 2.4, 0]} castShadow><sphereGeometry args={[1.3, 9, 8]} /><meshLambertMaterial color="#2e8b3a" /></mesh></group>;
  if (kind === 'pine') return <group position={[x, 0, z - 4]}><mesh position={[0, 0.7, 0]}><cylinderGeometry args={[0.2, 0.25, 1.4, 6]} /><meshLambertMaterial color="#5d4037" /></mesh><mesh position={[0, 2.3, 0]} castShadow><coneGeometry args={[1.3, 2.6, 8]} /><meshLambertMaterial color="#2f6f4f" /></mesh><mesh position={[0, 3.6, 0]}><coneGeometry args={[0.9, 1.8, 8]} /><meshLambertMaterial color="#e8f3f8" /></mesh></group>;
  if (kind === 'cactus') return <group position={[x, 0, z - 4]}><mesh position={[0, 1.2, 0]} castShadow><cylinderGeometry args={[0.3, 0.35, 2.4, 8]} /><meshLambertMaterial color="#3f8f4a" /></mesh><mesh position={[0.5, 1.6, 0]}><cylinderGeometry args={[0.16, 0.16, 0.9, 6]} /><meshLambertMaterial color="#3f8f4a" /></mesh></group>;
  if (kind === 'lamp') return <group position={[x, 0, side * 8]}><mesh position={[0, 2.2, 0]}><cylinderGeometry args={[0.08, 0.1, 4.4, 6]} /><meshLambertMaterial color="#444" /></mesh><mesh position={[0, 4.5, 0]}><sphereGeometry args={[0.3, 8, 8]} /><meshLambertMaterial color="#ffe9a0" emissive="#ffd54f" emissiveIntensity={2} /></mesh></group>;
  return <group position={[x, 0, side * 8]}><mesh position={[0, 0.5, 0]}><boxGeometry args={[3, 0.5, 0.15]} /><meshLambertMaterial color="#b0bec5" /></mesh><mesh position={[0, 2, 0]}><cylinderGeometry args={[0.07, 0.07, 4, 6]} /><meshLambertMaterial color="#607d8b" /></mesh></group>;
}

function Tile({ k, mult, state }: any) {
  const col = state === 'passed' ? '#ffc107' : state === 'hit' ? '#ef4444' : TILE_COLORS[k % TILE_COLORS.length];
  const label = (mult >= 100 ? Math.round(mult) : mult >= 10 ? mult.toFixed(1) : mult.toFixed(2)) + 'x';
  return (
    <group position={[laneX(k), 0.2, 3.9]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><circleGeometry args={[0.95, 28]} /><meshLambertMaterial color={col} emissive={col} emissiveIntensity={state === 'next' ? 1.4 : 0.7} transparent opacity={0.85} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}><ringGeometry args={[0.95, 1.1, 28]} /><meshBasicMaterial color={col} /></mesh>
      <Html center distanceFactor={9} position={[0, 0.5, 0]} style={{ pointerEvents: 'none' }} zIndexRange={[20, 0]}>
        <div className={`mtile ${state}`} style={{ ['--c' as any]: col }}>{label}</div>
      </Html>
    </group>
  );
}

function Track({ G, N, E, q, level, seed, table, round, envKey }: any) {
  const [c, setC] = useState(0);
  useFrame(() => { const l = Math.round(G.x / LW); if (l !== c) setC(l); });
  const lo = Math.max(1, c - 4), hi = Math.min(N, c + (q ? 8 : 6));
  const lanes: any[] = []; for (let k = lo; k <= hi; k++) lanes.push(k);
  const dstep = q ? 2 : 3, decor: any[] = [];
  for (let k = Math.max(-1, c - 6); k <= Math.min(N + 3, c + 12); k++) if (k % dstep === 0) { decor.push({ k, side: 1 }); decor.push({ k, side: -1 }); }
  const mid = laneX(N + 1) / 2;
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[mid, -0.2, 0]} receiveShadow><planeGeometry args={[laneX(N + 1) + 160, 90]} /><meshLambertMaterial color={E.ground} /></mesh>
      <mesh position={[0, 0.05, 0]} receiveShadow><boxGeometry args={[LW * 1.4, 0.3, 26]} /><meshLambertMaterial color={E.walk} /></mesh>
      <mesh position={[laneX(N + 1), 0.05, 0]} receiveShadow><boxGeometry args={[LW * 1.6, 0.3, 26]} /><meshLambertMaterial color="#ffd54f" emissive="#ff9800" emissiveIntensity={0.4} /></mesh>
      <Html center position={[laneX(N + 1), 1.8, 0]} distanceFactor={10} style={{ pointerEvents: 'none' }}><div className="text-xl font-black gold-text">FINISH</div></Html>
      {lanes.map((k) => {
        const st = k <= round.step ? 'passed' : round.status === 'lost' && k === round.step + 1 ? 'hit' : k === round.step + 1 && round.status === 'active' ? 'next' : 'future';
        return (
          <group key={k}>
            <mesh position={[laneX(k), 0, 0]} receiveShadow><boxGeometry args={[LW, 0.2, 26]} /><meshLambertMaterial color={k % 2 ? E.road : E.road2} /></mesh>
            <mesh position={[laneX(k) + LW / 2, 0.11, 0]}><boxGeometry args={[0.07, 0.02, 26]} /><meshBasicMaterial color="#f5f5f5" /></mesh>
            <Lane k={k} G={G} pat={lanePattern({ difficulties: round.cfgDiff }, level, k, seed)} />
            {table[k - 1] && <Tile k={k} mult={table[k - 1]} state={st} />}
          </group>
        );
      })}
      {decor.map((d) => <Decor key={d.k + '_' + d.side} kind={E.decor} x={laneX(d.k)} side={d.side} s={Math.abs(d.k * 7 + d.side * 3)} />)}
    </group>
  );
}

function Weather({ G, E, q }: any) {
  const n = E.rain ? (q ? 500 : 200) : E.snow ? (q ? 400 : 150) : 0; const ref = useRef<any>();
  const pos = useMemo(() => { const a = new Float32Array(Math.max(n, 1) * 3); for (let i = 0; i < n; i++) { a[i * 3] = (Math.random() - 0.5) * 44; a[i * 3 + 1] = Math.random() * 14; a[i * 3 + 2] = (Math.random() - 0.5) * 34; } return a; }, [n]);
  useFrame((_, dt) => {
    if (!ref.current || !n) return; const a = ref.current.geometry.attributes.position.array;
    for (let i = 0; i < n; i++) { a[i * 3 + 1] -= (E.rain ? 22 : 2.5) * dt; if (E.snow) a[i * 3] += Math.sin(G.clock + i) * 0.01; if (a[i * 3 + 1] < 0) a[i * 3 + 1] = 14; }
    ref.current.geometry.attributes.position.needsUpdate = true; ref.current.position.x = G.x;
  });
  if (!n) return null;
  return <points ref={ref} frustumCulled={false}><bufferGeometry><bufferAttribute attach="attributes-position" count={n} array={pos} itemSize={3} /></bufferGeometry><pointsMaterial color={E.rain ? '#9ecbff' : '#ffffff'} size={E.rain ? 0.07 : 0.16} transparent opacity={0.85} /></points>;
}

function Burst({ G, fx }: any) {
  const ref = useRef<any>(); const dummy = useMemo(() => new THREE.Object3D(), []);
  const P = useMemo(() => Array.from({ length: 36 }, () => ({ p: new THREE.Vector3(0, -9, 0), v: new THREE.Vector3(), l: 0 })), []);
  useFrame((_, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05); if (!ref.current) return;
    if (G.burst) { P.forEach((q) => { q.p.set(G.x, 0.8, 0); q.v.set((Math.random() - 0.3) * 4, Math.random() * 6 + 2, (Math.random() - 0.5) * 5); q.l = 1; }); G.burst = 0; }
    if (G.phase === 'hop' && Math.random() < 0.7) { const q = P[Math.floor(Math.random() * P.length)]; q.p.set(G.x, 0.5 + Math.random() * 0.6, 0); q.v.set(-1, Math.random() * 1.5, (Math.random() - 0.5) * 2); q.l = 0.7; }
    P.forEach((q, i) => { q.l -= dt * 1.1; if (q.l > 0) { q.v.y -= 12 * dt; q.p.addScaledVector(q.v, dt); } dummy.position.copy(q.p); const s = Math.max(q.l, 0) * 0.17; dummy.scale.set(s, s, s); dummy.updateMatrix(); ref.current.setMatrixAt(i, dummy.matrix); });
    ref.current.instanceMatrix.needsUpdate = true;
  });
  return <instancedMesh ref={ref} args={[undefined as any, undefined as any, 36]} frustumCulled={false}><sphereGeometry args={[1, 6, 6]} /><meshBasicMaterial color={FXC[fx] || '#ffd54f'} /></instancedMesh>;
}

function Rig({ G }: any) {
  const { camera, size } = useThree();
  useFrame((_, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05), port = size.width < size.height;
    const tx = G.x + (port ? -1 : -4), ty = port ? 9 : 6.5, tz = port ? 15 : 10.5;
    camera.position.x += (tx - camera.position.x) * Math.min(1, dt * 4); camera.position.y += (ty - camera.position.y) * Math.min(1, dt * 3); camera.position.z += (tz - camera.position.z) * Math.min(1, dt * 3);
    camera.lookAt(camera.position.x + (port ? 1.2 : 4.5), 0.6, port ? -4 : 0);
  });
  return null;
}
function Sun({ G, q, E }: any) {
  const l = useRef<any>();
  useFrame(() => { const d = l.current; if (!d) return; d.position.set(G.x + 6, 14, 8); d.target.position.set(G.x, 0, 0); d.target.updateMatrixWorld(); });
  return <directionalLight ref={l} intensity={E.sun} shadow-mapSize-width={1024} shadow-mapSize-height={1024} shadow-camera-left={-14} shadow-camera-right={14} shadow-camera-top={14} shadow-camera-bottom={-14} shadow-camera-far={50} />;
}

export default function Scene({ cmd, round, table, cfgDiff, skin, env, anim, fx, quality, onDone, onLow }: any) {
  const G: any = useMemo(() => ({ x: 0, phase: 'idle', t: 0, D: 0.5, from: 0, to: 0, hit: false, anim: 'hop', clock: 0, px: 0, py: 0, pz: 0, vy: 0, vz: 0, lane: 0, killer: null, burst: 0, onDone: null, reported: false }), []);
  G.onDone = onDone;
  useEffect(() => {
    if (!cmd) return;
    if (cmd.type === 'place') { G.x = laneX(cmd.to); G.lane = cmd.to; G.phase = 'idle'; G.killer = null; G.reported = false; }
    if (cmd.type === 'hop') {
      G.from = G.x; G.to = laneX(cmd.to); G.hit = cmd.hit; G.t = 0; G.anim = anim; G.D = anim === 'hop' ? 0.5 : 0.65; G.phase = 'hop'; G.lane = cmd.to; G.reported = false;
      if (cmd.hit) G.killer = { lane: cmd.to, t: 0, on: true, D: G.D };
    }
    if (cmd.type === 'win') { G.phase = 'win'; G.burst = 1; }
  }, [cmd]);
  const E = ENVS[env] || ENVS.city; const q = quality;
  const N = round.lanes;
  const [ver, setVer] = useState(0);
  return (
    <Boundary>
      <Canvas key={ver} flat dpr={1} camera={{ fov: 48, position: [-1, 9, 15], near: 0.1, far: 300 }}
        gl={{ antialias: false, alpha: false, stencil: false, powerPreference: 'default', failIfMajorPerformanceCaveat: false }}
        onCreated={({ gl, scene }) => {
          gl.setClearColor(E.sky);
          gl.domElement.addEventListener('webglcontextlost', (e: any) => { e.preventDefault(); setTimeout(() => setVer((v) => v + 1), 300); });
        }}>
        <color attach="background" args={[E.sky]} />
        <ambientLight intensity={Math.max(E.amb, 0.8)} />
        <hemisphereLight args={[E.sky, E.ground, 0.6]} />
        <Sun G={G} q={0} E={E} />
        <Rig G={G} />
        <Track G={G} N={N} E={E} q={q} level={round.level} seed={round.seed} table={table} round={{ ...round, cfgDiff }} envKey={env} />
        <Chicken G={G} skin={skin} />
        <Killer G={G} />
        <Burst G={G} fx={fx} />
        <Weather G={G} E={E} q={q} />
      </Canvas>
    </Boundary>
  );
}

class Boundary extends React.Component<any, any> {
  state = { err: null as any };
  static getDerivedStateFromError(err: any) { return { err }; }
  render() {
    if (this.state.err) return <div style={{ position: 'absolute', inset: 0, padding: 16, color: '#fff', fontSize: 12, background: '#1b1030', overflow: 'auto' }}>3D error: {String(this.state.err && (this.state.err.message || this.state.err))}</div>;
    return this.props.children;
  }
}
