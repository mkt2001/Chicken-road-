import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useStore, doAct, toast, api, REMOTE, logout, resetLocal } from '../store';
import { Btn, Header, Wallet, Avatar, AVATARS, fmt, fmtM, Modal } from '../ui';
import { SKINS, ENVS } from '../game/Scene';
import { sfx } from '../audio';
import { dayKey } from '../../shared/service.js';

const Page = ({ children }: any) => <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} className="absolute inset-0 flex flex-col">{children}</motion.div>;
const vip = (s: any) => Math.min(10, Math.floor(s.stats.earned / 50000));

export function Home({ go }: any) {
  const { state: s, cfg, user } = useStore(); const today = dayKey(Date.now());
  const claimable = s.daily.last !== today, spinFree = s.wheel !== today;
  const mClaim = cfg.missions.some((m: any) => !s.mis.c[m.id] && (s.mis.p[m.id] || 0) >= m.target);
  const tiles = [['rewards', '🎁', 'Daily Rewards', claimable || spinFree], ['missions', '📋', 'Missions', mClaim], ['leaderboard', '🏅', 'Leaderboard'], ['shop', '🛍️', 'Skin Shop'], ['profile', '📊', 'Statistics'], ['vip', '👑', 'VIP Collection'], ['wallet', '👛', 'Wallet'], ['settings', '⚙️', 'Settings']];
  return (
    <Page>
      <div className="safe-top flex items-center justify-between gap-2 px-4">
        <button onClick={() => go('profile')} className="flex items-center gap-2 text-left"><Avatar s={s} size={50} /><div><div className="font-black leading-tight">{s.name}</div><div className="text-xs text-yellow-300">VIP {vip(s)} · {user && user.role === 'admin' ? 'Admin' : REMOTE ? 'Online' : 'Offline mode'}</div></div></button>
        <Wallet s={s} />
      </div>
      {cfg.event && cfg.event.active && <div className="mx-4 mt-2 rounded-xl bg-gradient-to-r from-fuchsia-600 to-orange-500 px-3 py-1 text-center text-sm font-black">🎉 {cfg.event.name}: +{cfg.event.pct}% on daily & wheel coins!</div>}
      <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
        <div className="text-7xl floaty">🐔</div>
        <div className="mt-2 text-4xl font-black gold-text leading-none">CHICKEN ROAD</div>
        <div className="text-lg font-black tracking-[0.3em] text-fuchsia-300">GOLDEN RUN</div>
        <Btn kind="gold" className="mt-6 w-full max-w-xs !py-4 text-2xl" onClick={() => go('modes')}>▶ PLAY NOW</Btn>
        {s.round && s.round.status === 'active' && <Btn kind="green" className="mt-3 w-full max-w-xs" onClick={() => go('game', s.round.mode)}>Resume round ({fmtM(s.round.mult)})</Btn>}
      </div>
      <div className="safe-bot grid grid-cols-4 gap-2 px-3">
        {tiles.map((t: any) => (
          <button key={t[0]} onClick={() => { sfx.click(); go(t[0]); }} className="glass relative flex flex-col items-center py-2 text-[11px] font-bold active:scale-95">
            <span className="text-2xl">{t[1]}</span>{t[2]}{t[3] && <span className="absolute right-1 top-1 h-3 w-3 rounded-full bg-red-500" />}
          </button>))}
      </div>
    </Page>
  );
}

export function Modes({ go, back }: any) {
  const { cfg, state: s } = useStore();
  return (
    <Page><Header title="Choose Mode" onBack={back} right={<Wallet s={s} />} />
      <div className="scroll-y flex-1 space-y-3 px-4 pb-6">
        {Object.entries(cfg.modes).map(([k, m]: any) => (
          <button key={k} onClick={() => { sfx.click(); go('game', k); }} className="glass flex w-full items-center gap-3 p-4 text-left active:scale-[0.98]">
            <span className="text-4xl">{m.icon}</span>
            <div className="flex-1"><div className="text-lg font-black">{m.name}</div><div className="text-xs text-white/70">{m.desc}</div><div className="mt-1 text-[11px] text-yellow-300">{m.lanes} lanes{m.timer ? ` · ${m.timer}s` : ''} · risk ×{m.risk}{m.minLevel > 1 ? ` · Lv${m.minLevel}+` : ''}</div></div><span className="text-2xl">›</span>
          </button>))}
      </div>
    </Page>
  );
}

export function Rewards({ back }: any) {
  const { cfg, state: s } = useStore(); const today = dayKey(Date.now());
  const [hl, setHl] = useState(-1); const [spinning, setSpinning] = useState(false); const [box, setBox] = useState<any>(null);
  const claimed = s.daily.last === today;
  const contin = s.daily.last === dayKey(Date.now() - 86400000);
  const doneCount = claimed ? ((s.daily.streak - 1) % 7) + 1 : contin ? s.daily.streak % 7 : 0;
  const curIdx = claimed ? -1 : doneCount;
  async function claim() { const r = await doAct('claimDaily'); if (!r.ok) return toast(r.error, 'error'); sfx.coin(); toast(`+${fmt(r.amount)} coins! Day ${r.day}`, 'good'); }
  async function spin() {
    if (spinning) return; const r = await doAct('spin'); if (!r.ok) return toast(r.error, 'error');
    setSpinning(true); const n = cfg.wheel.length, total = 24 + r.index; let i = 0;
    const step = () => { setHl(i % n); sfx.click(); i++; if (i <= total) setTimeout(step, 60 + i * 7); else { setSpinning(false); sfx.win(); toast('You won ' + r.seg.label + '!', 'good'); } };
    step();
  }
  async function open() { const r = await doAct('openBox'); if (!r.ok) return toast(r.error, 'error'); sfx.win(); setBox(r.res); }
  return (
    <Page><Header title="Rewards" onBack={back} right={<Wallet s={s} />} />
      <div className="scroll-y flex-1 space-y-4 px-4 pb-6">
        <div className="glass p-3">
          <div className="mb-2 flex justify-between font-black"><span>📅 Daily Login</span><span className="text-orange-300">🔥 Streak {s.daily.streak}</span></div>
          <div className="grid grid-cols-7 gap-1">{cfg.daily.map((v: number, i: number) => { const done = i < doneCount, cur = i === curIdx;
            return <div key={i} className={`rounded-lg py-2 text-center text-[11px] font-bold ${cur ? 'btn-gold' : done ? 'bg-emerald-600/70' : 'bg-white/10'}`}>D{i + 1}<br />{v}{i === 6 && <div>+💎</div>}</div>; })}</div>
          <Btn kind="gold" className="mt-3 w-full" disabled={claimed} onClick={claim}>{claimed ? 'Come back tomorrow' : 'Claim Today\'s Reward'}</Btn>
        </div>
        <div className="glass p-3">
          <div className="mb-2 font-black">🎡 Lucky Wheel <span className="text-xs font-normal text-white/60">({s.wheel !== today ? 'free spin ready' : `extra spin 🪙 ${cfg.wheelCost}`})</span></div>
          <div className="grid grid-cols-4 gap-2">{cfg.wheel.map((w: any, i: number) => <div key={i} className={`rounded-xl py-3 text-center text-sm font-black transition ${hl === i ? 'btn-gold scale-110' : 'bg-white/10'}`}>{w.label}</div>)}</div>
          <Btn kind="purple" className="mt-3 w-full" disabled={spinning} onClick={spin}>{spinning ? 'Spinning…' : s.wheel !== today ? 'SPIN FREE' : `SPIN · 🪙 ${cfg.wheelCost}`}</Btn>
        </div>
        <div className="glass p-3 text-center">
          <div className="text-5xl floaty">🎁</div><div className="font-black">Mystery Box</div>
          <div className="text-xs text-white/70">Coins, diamonds or a random cosmetic item</div>
          <Btn kind="purple" className="mt-2 w-full" onClick={open}>OPEN · 🪙 {cfg.boxCost}</Btn>
        </div>
      </div>
      {box && <Modal onClose={() => setBox(null)}><div className="text-center"><div className="text-5xl">🎉</div><div className="mt-2 text-xl font-black gold-text">You got</div>
        <div className="mt-1 text-2xl font-black">{box.gold ? `🪙 ${fmt(box.gold)}` : box.diamonds ? `💎 ${box.diamonds}` : box.item.name}</div><Btn className="mt-4 w-full" onClick={() => setBox(null)}>Nice!</Btn></div></Modal>}
    </Page>
  );
}

export function Missions({ back }: any) {
  const { cfg, state: s } = useStore(); const [tab, setTab] = useState('daily');
  const list = cfg.missions.filter((m: any) => m.type === tab);
  const dailies = cfg.missions.filter((m: any) => m.type === 'daily'); const dc = dailies.filter((m: any) => s.mis.c[m.id]).length;
  async function claim(id: string) { const r = await doAct('claimMission', { id }); if (!r.ok) return toast(r.error, 'error'); sfx.coin(); toast(r.bonus ? `Mission done! +${r.bonus} bonus` : 'Reward claimed!', 'good'); }
  return (
    <Page><Header title="Missions" onBack={back} />
      <div className="mb-2 flex gap-2 px-4">{['daily', 'weekly', 'achievements'].map((t) => <Btn key={t} kind={tab === t ? 'purple' : 'dark'} className="flex-1 !px-1 !py-2 text-sm capitalize" onClick={() => setTab(t)}>{t}</Btn>)}</div>
      <div className="scroll-y flex-1 space-y-2 px-4 pb-6">
        {tab === 'daily' && <div className="glass p-2 text-center text-xs text-yellow-300">Claim all 5 daily missions ({dc}/5) for a +{cfg.missionBonus} coin bonus</div>}
        {tab !== 'achievements' && list.map((m: any) => { const p = Math.min(m.target, s.mis.p[m.id] || 0), ok = p >= m.target, done = s.mis.c[m.id];
          return <div key={m.id} className="glass p-3"><div className="flex items-center justify-between"><div className="font-bold">{m.title}</div><div className="text-sm text-yellow-300">🪙 {fmt(m.gold)}{m.diamonds ? ` +💎${m.diamonds}` : ''}</div></div>
            <div className="mt-2 flex items-center gap-2"><div className="h-2 flex-1 overflow-hidden rounded-full bg-white/15"><div className="h-full bg-gradient-to-r from-purple-500 to-yellow-400" style={{ width: `${(p / m.target) * 100}%` }} /></div><span className="text-xs">{p}/{m.target}</span>
              <Btn kind="green" className="!px-3 !py-1 text-sm" disabled={!ok || done} onClick={() => claim(m.id)}>{done ? '✓' : 'Claim'}</Btn></div></div>; })}
        {tab === 'achievements' && cfg.achievements.map((a: any) => { const v = a.stat === 'gold' ? s.gold : a.stat === 'owned' ? s.owned.length : s.stats[a.stat], d = !!s.ach[a.id];
          return <div key={a.id} className={`glass flex items-center gap-3 p-3 ${d ? '' : 'opacity-80'}`}><span className="text-3xl">{d ? '🏆' : '🔒'}</span><div className="flex-1"><div className="font-bold">{a.title}</div><div className="text-xs text-white/70">{fmt(Math.min(v, a.target))}/{fmt(a.target)} · reward 🪙 {a.gold} · {a.pts} pts</div></div></div>; })}
      </div>
    </Page>
  );
}

const BOTS = ['SpeedyHen', 'RoadKing', 'CluckNorris', 'NeonFeather', 'TurboRooster', 'GoldenEgg', 'ZigZagBird', 'NightCrosser', 'MegaCluck', 'FoxyChick'];
export function Leaderboard({ back }: any) {
  const { state: s } = useStore(); const [tab, setTab] = useState('global'); const [rows, setRows] = useState<any[]>([]); const [friend, setFriend] = useState('');
  async function load() {
    if (REMOTE) { const j = await api('/api/leaderboard?period=' + tab); if (j.ok) setRows(j.rows); else toast(j.error, 'error'); return; }
    const k = tab === 'week' ? ['wMult', 'wScore'] : tab === 'month' ? ['mMult', 'mScore'] : null;
    const mine = { name: s.name, avatar: s.avatar, frame: s.eq.frame, mult: k ? s.lb[k[0]] : s.stats.bestMult, score: k ? s.lb[k[1]] : s.stats.bestScore, crossings: s.stats.crossings, ap: s.lb.ap, me: true };
    const bots = BOTS.map((n, i) => ({ name: n, avatar: i % 8, frame: 'frame_none', mult: Math.round(400 / (i + 1.3) * (tab === 'week' ? 0.5 : tab === 'month' ? 0.8 : 1) * 100) / 100, score: Math.round(40000 / (i + 1)), crossings: 900 - i * 70, ap: 300 - i * 20 }));
    setRows([...bots, mine].sort((a: any, b: any) => b.mult - a.mult).map((r: any, i: number) => ({ ...r, rank: i + 1 })));
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [tab]);
  async function addFriend() { const j = await api('/api/friends/add', 'POST', { name: friend }); if (j.ok) { toast('Friend added', 'good'); setFriend(''); load(); } else toast(j.error, 'error'); }
  return (
    <Page><Header title="Leaderboard" onBack={back} />
      <div className="mb-2 flex gap-1 px-4">{['global', 'week', 'month', 'friends'].map((t) => <Btn key={t} kind={tab === t ? 'purple' : 'dark'} className="flex-1 !px-1 !py-2 text-xs capitalize" onClick={() => setTab(t)}>{t === 'week' ? 'Weekly' : t === 'month' ? 'Monthly' : t}</Btn>)}</div>
      {tab === 'friends' && REMOTE && <div className="mb-2 flex gap-2 px-4"><input value={friend} onChange={(e) => setFriend(e.target.value)} placeholder="Friend's username" className="min-w-0 flex-1 rounded-xl bg-black/40 px-3 py-2 outline-none" /><Btn kind="green" className="!py-2" onClick={addFriend}>Add</Btn></div>}
      {tab === 'friends' && !REMOTE && <div className="mx-4 mb-2 rounded-xl bg-white/10 p-2 text-center text-xs">Friends need online mode. Showing rival players.</div>}
      <div className="scroll-y flex-1 space-y-2 px-4 pb-6">
        {rows.length === 0 && <div className="mt-10 text-center text-white/60">No scores yet. Cash out to get on the board!</div>}
        {rows.map((r: any) => (
          <div key={r.rank} className={`glass flex items-center gap-3 p-2 ${r.me ? 'ring-2 ring-yellow-400' : ''}`}>
            <div className="w-8 text-center text-xl font-black">{r.rank <= 3 ? ['🥇', '🥈', '🥉'][r.rank - 1] : r.rank}</div>
            <Avatar s={{ avatar: r.avatar, eq: { frame: r.frame } }} size={42} />
            <div className="min-w-0 flex-1"><div className="truncate font-bold">{r.name}{r.me ? ' (You)' : ''}</div><div className="text-[11px] text-white/70">Score {fmt(r.score)} · {fmt(r.crossings)} crossings · {r.ap} pts</div></div>
            <div className="text-lg font-black gold-text">{fmtM(r.mult)}</div>
          </div>))}
      </div>
    </Page>
  );
}

function Preview({ it }: any) {
  const k = it.id.split('_')[1];
  if (it.cat === 'skin') { const sk = SKINS[k]; return <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full text-3xl" style={{ background: `radial-gradient(circle at 35% 30%, ${sk.body}, ${sk.wing})`, boxShadow: `0 0 16px ${sk.ei ? sk.emi : sk.comb}` }}>🐔</div>; }
  if (it.cat === 'road') { const e = ENVS[k]; return <div className="mx-auto h-16 w-16 overflow-hidden rounded-xl" style={{ background: `linear-gradient(${e.sky} 45%, ${e.road} 45%)` }} />; }
  const icon: any = { bg: '🌌', anim: k === 'flip' ? '🤸' : k === 'spin' ? '🌀' : '🐇', sfx: '🔊', fx: k === 'fire' ? '🔥' : k === 'neon' ? '💠' : k === 'stars' ? '🌟' : '✨', frame: '🖼️' };
  return <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-xl bg-white/10 text-4xl">{icon[it.cat]}</div>;
}
const CATS: any = [['skin', 'Skins'], ['road', 'Roads'], ['bg', 'Menus'], ['anim', 'Moves'], ['sfx', 'Sounds'], ['fx', 'Effects'], ['frame', 'Frames']];
function ItemGrid({ items }: any) {
  const { state: s } = useStore();
  async function buy(it: any) { const r = await doAct('buy', { id: it.id }); if (!r.ok) return toast(r.error, 'error'); sfx.win(); toast(it.name + ' unlocked & equipped!', 'good'); }
  async function equip(it: any) { const r = await doAct('equip', { id: it.id }); if (!r.ok) toast(r.error, 'error'); else sfx.click(); }
  return (
    <div className="grid grid-cols-2 gap-3">{items.map((it: any) => { const own = s.owned.includes(it.id), on = s.eq[it.cat] === it.id;
      return <div key={it.id} className={`glass p-3 text-center ${on ? 'ring-2 ring-emerald-400' : ''}`}><Preview it={it} />
        <div className="mt-2 text-sm font-black leading-tight">{it.name}</div><div className="text-[11px] text-white/60">{it.desc}</div>
        {own ? <Btn kind={on ? 'dark' : 'green'} className="mt-2 w-full !py-1 text-sm" disabled={on} onClick={() => equip(it)}>{on ? 'Equipped' : 'Equip'}</Btn>
          : <Btn kind="gold" className="mt-2 w-full !py-1 text-sm" onClick={() => buy(it)}>{it.diamonds ? `💎 ${it.diamonds}` : `🪙 ${fmt(it.gold)}`}</Btn>}</div>; })}</div>
  );
}
export function Shop({ back }: any) {
  const { cfg, state: s } = useStore(); const [cat, setCat] = useState('skin');
  return (
    <Page><Header title="Shop" onBack={back} right={<Wallet s={s} />} />
      <div className="mb-2 flex gap-1 overflow-x-auto px-4 pb-1">{CATS.map((c: any) => <Btn key={c[0]} kind={cat === c[0] ? 'purple' : 'dark'} className="shrink-0 !px-3 !py-2 text-sm" onClick={() => setCat(c[0])}>{c[1]}</Btn>)}</div>
      <div className="scroll-y flex-1 px-4 pb-6"><ItemGrid items={cfg.items.filter((i: any) => i.cat === cat)} /></div>
    </Page>
  );
}
export function Vip({ back }: any) {
  const { cfg, state: s } = useStore(); const lv = vip(s); const list = cfg.items.filter((i: any) => i.diamonds > 0);
  return (
    <Page><Header title="VIP Collection" onBack={back} right={<Wallet s={s} />} />
      <div className="scroll-y flex-1 space-y-3 px-4 pb-6">
        <div className="glass p-3 text-center"><div className="text-3xl">👑</div><div className="text-xl font-black gold-text">VIP Level {lv}</div>
          <div className="mx-auto mt-2 h-2 w-full overflow-hidden rounded-full bg-white/15"><div className="h-full bg-gradient-to-r from-yellow-300 to-orange-500" style={{ width: `${lv >= 10 ? 100 : ((s.stats.earned % 50000) / 50000) * 100}%` }} /></div>
          <div className="mt-1 text-xs text-white/70">Earn 50,000 total coins per level · Collected {list.filter((i: any) => s.owned.includes(i.id)).length}/{list.length} exclusives</div></div>
        <ItemGrid items={list} />
      </div>
    </Page>
  );
}

export function Profile({ back }: any) {
  const { cfg, state: s } = useStore(); const [name, setName] = useState(s.name); const st = s.stats;
  const stats = [['Total Coins Earned', fmt(st.earned)], ['Games Played', st.games], ['Wins', st.wins], ['Highest Multiplier', fmtM(st.bestMult || 0)], ['Best Score', fmt(st.bestScore)], ['Total Crossings', fmt(st.crossings)], ['Best Win Streak', st.bestStreak], ['Achievement Pts', s.lb.ap]];
  async function save(avatar = s.avatar) { const r = await doAct('setProfile', { name, avatar }); if (!r.ok) toast(r.error, 'error'); else toast('Profile saved', 'good'); }
  return (
    <Page><Header title="Profile & Stats" onBack={back} />
      <div className="scroll-y flex-1 space-y-3 px-4 pb-6">
        <div className="glass flex flex-col items-center p-4"><Avatar s={s} size={84} />
          <div className="mt-3 flex gap-1">{AVATARS.map((a, i) => <button key={i} onClick={() => save(i)} className={`h-9 w-9 rounded-full text-xl ${s.avatar === i ? 'bg-yellow-400/40' : 'bg-white/10'}`}>{a}</button>)}</div>
          <div className="mt-3 flex w-full gap-2"><input value={name} maxLength={16} onChange={(e) => setName(e.target.value)} className="min-w-0 flex-1 rounded-xl bg-black/40 px-3 py-2 outline-none" /><Btn kind="green" className="!py-2" onClick={() => save()}>Save</Btn></div></div>
        <div className="grid grid-cols-2 gap-2">{stats.map((x: any) => <div key={x[0]} className="glass p-3 text-center"><div className="text-lg font-black text-yellow-300">{x[1]}</div><div className="text-[11px] text-white/70">{x[0]}</div></div>)}</div>
        <div className="glass p-3"><div className="mb-2 font-black">Unlocked Characters</div><div className="flex flex-wrap gap-2">{cfg.items.filter((i: any) => i.cat === 'skin' && s.owned.includes(i.id)).map((i: any) => <span key={i.id} className="rounded-full bg-white/10 px-3 py-1 text-xs font-bold">{i.name}</span>)}</div></div>
        <div className="glass p-3"><div className="mb-2 font-black">Achievements ({Object.keys(s.ach).length}/{cfg.achievements.length})</div><div className="flex flex-wrap gap-2">{cfg.achievements.map((a: any) => <span key={a.id} className={`rounded-full px-3 py-1 text-xs font-bold ${s.ach[a.id] ? 'bg-emerald-600' : 'bg-white/10 opacity-60'}`}>{s.ach[a.id] ? '🏆' : '🔒'} {a.title}</span>)}</div></div>
      </div>
    </Page>
  );
}

export function WalletScreen({ back }: any) {
  const { cfg, state: s } = useStore(); const ex = cfg.exchange; const [qty, setQty] = useState(1);
  async function exch(dir: string) { const r = await doAct('exchange', { dir, qty }); if (!r.ok) return toast(r.error, 'error'); sfx.coin(); toast('Exchanged!', 'good'); }
  async function refill() { const r = await doAct('refill'); if (!r.ok) return toast(r.error, 'error'); sfx.coin(); toast(`+${cfg.refill.amount} free coins`, 'good'); }
  return (
    <Page><Header title="Wallet" onBack={back} />
      <div className="scroll-y flex-1 space-y-3 px-4 pb-6">
        <div className="glass p-4 text-center"><div className="text-xs text-white/60">Virtual coins only · no real money value</div><Wallet s={s} /></div>
        <div className="glass p-3"><div className="mb-2 font-black">🏪 Coin Shop</div>
          <div className="mb-2 flex items-center gap-2"><span className="text-sm">Diamonds:</span>{[1, 5, 10].map((n) => <Btn key={n} kind={qty === n ? 'purple' : 'dark'} className="!px-3 !py-1 text-sm" onClick={() => setQty(n)}>{n}</Btn>)}</div>
          <div className="flex gap-2"><Btn kind="gold" className="flex-1 !px-1 text-xs" onClick={() => exch('toDiamonds')}>🪙 {fmt(qty * ex.goldPerDiamond)} → 💎 {qty}</Btn><Btn kind="purple" className="flex-1 !px-1 text-xs" onClick={() => exch('toGold')}>💎 {qty} → 🪙 {fmt(qty * ex.diamondToGold)}</Btn></div>
          <Btn kind="green" className="mt-2 w-full text-sm" onClick={refill}>Free refill (when under {cfg.refill.below} coins)</Btn></div>
        <div className="glass p-3"><div className="mb-2 font-black">Transaction History</div>
          {s.history.length === 0 && <div className="text-sm text-white/60">No transactions yet.</div>}
          {s.history.slice(0, 40).map((h: any, i: number) => <div key={i} className="flex items-center justify-between border-b border-white/10 py-1 text-sm"><div><div>{h.note}</div><div className="text-[10px] text-white/50">{new Date(h.t).toLocaleString()}</div></div>
            <div className={`font-black ${h.amount >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>{h.amount >= 0 ? '+' : ''}{fmt(h.amount)} {h.cur === 'd' ? '💎' : '🪙'}</div></div>)}</div>
      </div>
    </Page>
  );
}

export function Settings({ back, go }: any) {
  const { state: s, user } = useStore(); const st = s.settings;
  const set = (o: any) => doAct('setSettings', o);
  const Row = ({ label, children }: any) => <div className="glass flex items-center justify-between p-3"><span className="font-bold">{label}</span>{children}</div>;
  const Tog = ({ on, f }: any) => <button onClick={() => { sfx.click(); f(!on); }} className={`h-7 w-14 rounded-full p-1 transition ${on ? 'bg-emerald-500' : 'bg-white/20'}`}><div className={`h-5 w-5 rounded-full bg-white transition ${on ? 'translate-x-7' : ''}`} /></button>;
  return (
    <Page><Header title="Settings" onBack={back} />
      <div className="scroll-y flex-1 space-y-2 px-4 pb-6">
        <Row label="🎵 Music"><Tog on={st.music} f={(v: boolean) => set({ music: v })} /></Row>
        <Row label="🔊 Sound effects"><Tog on={st.sfx} f={(v: boolean) => set({ sfx: v })} /></Row>
        <Row label="Volume"><input type="range" min={0} max={1} step={0.05} value={st.vol} onChange={(e) => set({ vol: Number(e.target.value) })} className="w-40" /></Row>
        <Row label="Graphics"><div className="flex gap-1">{['auto', 'low', 'medium', 'high'].map((q) => <button key={q} onClick={() => set({ quality: q })} className={`rounded-lg px-2 py-1 text-xs font-bold capitalize ${st.quality === q ? 'btn-purple' : 'btn-dark'}`}>{q}</button>)}</div></Row>
        {user && user.role === 'admin' && <Btn kind="purple" className="w-full" onClick={() => go('admin')}>🛠 Admin Dashboard</Btn>}
        {REMOTE ? <Btn kind="dark" className="w-full" onClick={() => logout()}>Log out ({user ? user.name : ''})</Btn>
          : <Btn kind="dark" className="w-full" onClick={() => { if (confirm('Reset ALL progress on this device?')) { resetLocal(); toast('Progress reset', 'good'); } }}>Reset progress</Btn>}
        <div className="pt-3 text-center text-xs text-white/50">Chicken Road – Golden Run v1.0 · Virtual coins only. No real-money gambling.</div>
      </div>
    </Page>
  );
}
