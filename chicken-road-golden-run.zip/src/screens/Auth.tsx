import React, { useEffect, useRef, useState } from 'react';
import { guestLogin, emailAuth, googleLogin, toast, GOOGLE_ID } from '../store';
import { Btn } from '../ui';

export default function Auth() {
  const [mode, setMode] = useState('guest'); const [email, setEmail] = useState(''); const [pw, setPw] = useState(''); const [name, setName] = useState(''); const [busy, setBusy] = useState(false);
  const gbtn = useRef<any>(null);
  useEffect(() => {
    if (!GOOGLE_ID) return;
    const init = () => { const g = (window as any).google; if (!g || !gbtn.current) return; g.accounts.id.initialize({ client_id: GOOGLE_ID, callback: async (r: any) => { const j = await googleLogin(r.credential); if (!j.ok) toast(j.error, 'error'); } }); g.accounts.id.renderButton(gbtn.current, { theme: 'filled_blue', size: 'large', width: 260 }); };
    if ((window as any).google) init(); else { const s = document.createElement('script'); s.src = 'https://accounts.google.com/gsi/client'; s.async = true; s.onload = init; document.body.appendChild(s); }
  }, []);
  async function run(f: () => Promise<any>) { setBusy(true); const j = await f(); setBusy(false); if (!j.ok) toast(j.error || 'Login failed', 'error'); }
  const inp = 'w-full rounded-xl bg-black/40 px-4 py-3 outline-none';
  return (
    <div className="bg-dusk absolute inset-0 flex flex-col items-center justify-center gap-3 px-8 text-center">
      <div className="text-7xl floaty">🐔</div>
      <div className="text-3xl font-black gold-text">CHICKEN ROAD</div>
      <div className="mb-2 font-black tracking-[0.3em] text-fuchsia-300">GOLDEN RUN</div>
      {mode === 'guest' ? (
        <>
          <Btn kind="gold" className="w-full max-w-xs !py-4 text-xl" disabled={busy} onClick={() => run(guestLogin)}>▶ Play as Guest</Btn>
          <Btn kind="purple" className="w-full max-w-xs" onClick={() => setMode('login')}>✉️ Email Login</Btn>
          {GOOGLE_ID ? <div ref={gbtn} className="mt-1" /> : <div className="text-xs text-white/40">Google login is available when VITE_GOOGLE_CLIENT_ID is set</div>}
        </>
      ) : (
        <div className="w-full max-w-xs space-y-3">
          {mode === 'register' && <input className={inp} placeholder="Username" value={name} onChange={(e) => setName(e.target.value)} />}
          <input className={inp} placeholder="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className={inp} placeholder="Password (6+ chars)" type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
          <Btn kind="gold" className="w-full" disabled={busy} onClick={() => run(() => emailAuth(mode, email, pw, name))}>{mode === 'login' ? 'Log in' : 'Create account'}</Btn>
          <button className="text-sm text-fuchsia-300" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'New here? Create an account' : 'Already have an account? Log in'}</button><br />
          <button className="text-sm text-white/60" onClick={() => setMode('guest')}>← Back</button>
        </div>
      )}
    </div>
  );
}
