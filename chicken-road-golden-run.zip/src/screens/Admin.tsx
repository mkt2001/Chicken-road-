import React, { useEffect, useState } from 'react';
import { api, REMOTE, toast, useStore } from '../store';
import { Btn, Header, fmt } from '../ui';

const KEYS = ['rtp', 'maxMult', 'minStake', 'maxStake', 'startGold', 'startDiamonds', 'weights', 'hazard', 'difficulties', 'modes', 'daily', 'event', 'missions', 'achievements', 'wheel', 'box', 'exchange', 'refill', 'items', 'wheelCost', 'boxCost', 'missionBonus'];
export default function Admin({ back }: any) {
  const { user, cfg } = useStore(); const [tab, setTab] = useState('stats'); const [stats, setStats] = useState<any>(null); const [rows, setRows] = useState<any[]>([]);
  const [key, setKey] = useState('rtp'); const [text, setText] = useState(''); const [grant, setGrant] = useState<any>({ gold: 1000, diamonds: 0 });
  async function load() {
    if (tab === 'stats') { const j = await api('/api/admin/stats'); if (j.ok) setStats(j); else toast(j.error, 'error'); }
    if (tab === 'players') { const j = await api('/api/admin/players'); if (j.ok) setRows(j.rows); else toast(j.error, 'error'); }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [tab]);
  useEffect(() => { setText(JSON.stringify(cfg[key], null, 1)); }, [key, cfg]);
  async function saveCfg() {
    let v; try { v = JSON.parse(text); } catch (e) { return toast('Invalid JSON', 'error'); }
    const j = await api('/api/admin/config', 'PUT', { key, value: v }); if (j.ok) { toast('Saved – applies to new rounds', 'good'); } else toast(j.error, 'error');
  }
  async function resetCfg() { const j = await api('/api/admin/config/' + key, 'DELETE'); if (j.ok) toast('Reset to default', 'good'); }
  async function act(path: string, body: any) { const j = await api(path, 'POST', body); if (j.ok) { toast('Done', 'good'); load(); } else toast(j.error, 'error'); }
  if (!REMOTE || !user || user.role !== 'admin') return <div className="absolute inset-0"><Header title="Admin" onBack={back} /><div className="p-6 text-center text-white/70">The admin dashboard needs server mode and an admin account.<br />Build with VITE_REMOTE=1 and log in with the admin email/password you set on the server.</div></div>;
  return (
    <div className="absolute inset-0 flex flex-col"><Header title="Admin Dashboard" onBack={back} />
      <div className="mb-2 flex gap-2 px-4">{['stats', 'players', 'config'].map((t) => <Btn key={t} kind={tab === t ? 'purple' : 'dark'} className="flex-1 !py-2 capitalize" onClick={() => setTab(t)}>{t}</Btn>)}</div>
      <div className="scroll-y flex-1 px-4 pb-6">
        {tab === 'stats' && stats && <div className="grid grid-cols-2 gap-2">{[['Players', stats.players], ['Rounds played', stats.rounds], ['Coins held', fmt(stats.totalGold)], ['Coins earned', fmt(stats.totalEarned)], ['Banned', stats.banned]].map((x: any) => <div key={x[0]} className="glass p-3 text-center"><div className="text-xl font-black text-yellow-300">{x[1]}</div><div className="text-xs text-white/70">{x[0]}</div></div>)}</div>}
        {tab === 'players' && <div className="space-y-2">
          <div className="glass flex gap-2 p-2 text-sm">Grant: <input className="w-20 rounded bg-black/40 px-2" value={grant.gold} onChange={(e) => setGrant({ ...grant, gold: e.target.value })} />🪙 <input className="w-14 rounded bg-black/40 px-2" value={grant.diamonds} onChange={(e) => setGrant({ ...grant, diamonds: e.target.value })} />💎</div>
          {rows.map((r) => <div key={r.id} className="glass p-2 text-sm"><div className="flex justify-between"><b>{r.name}{r.role === 'admin' ? ' (admin)' : ''}</b><span className={r.banned ? 'text-red-400' : 'text-emerald-300'}>{r.banned ? 'banned' : 'active'}</span></div>
            <div className="text-xs text-white/60">{r.email || r.id} · 🪙 {fmt(r.gold)} · 💎 {r.diamonds} · {r.games} games</div>
            <div className="mt-1 flex gap-2"><Btn kind="green" className="!px-3 !py-1 text-xs" onClick={() => act('/api/admin/grant', { id: r.id, gold: grant.gold, diamonds: grant.diamonds })}>Grant</Btn>
              {r.role !== 'admin' && <Btn kind="dark" className="!px-3 !py-1 text-xs" onClick={() => act('/api/admin/ban', { id: r.id, banned: !r.banned })}>{r.banned ? 'Unban' : 'Ban'}</Btn>}</div></div>)}</div>}
        {tab === 'config' && <div className="space-y-2">
          <select value={key} onChange={(e) => setKey(e.target.value)} className="w-full rounded-xl bg-black/60 px-3 py-2">{KEYS.map((k) => <option key={k} value={k}>{k}</option>)}</select>
          <textarea value={text} onChange={(e) => setText(e.target.value)} className="h-72 w-full rounded-xl bg-black/50 p-2 font-mono text-xs outline-none" />
          <div className="flex gap-2"><Btn kind="green" className="flex-1" onClick={saveCfg}>Save</Btn><Btn kind="dark" className="flex-1" onClick={resetCfg}>Reset to default</Btn></div>
          <div className="text-xs text-white/50">Edit difficulties, multipliers (rtp/hazard), modes, rewards, shop items and events without touching code. Players get new settings on their next login or refresh.</div></div>}
      </div>
    </div>
  );
}
