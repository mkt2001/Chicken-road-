import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { sfx } from './audio';

export const AVATARS = ['🐔', '🐣', '🐓', '🦆', '🦅', '🦉', '🦜', '🐧'];
export const FRAMES: any = {
  frame_none: 'ring-2 ring-white/20',
  frame_gold: 'ring-4 ring-yellow-400 shadow-[0_0_14px_#facc15]',
  frame_neon: 'ring-4 ring-fuchsia-500 shadow-[0_0_14px_#d946ef]',
  frame_fire: 'ring-4 ring-orange-500 shadow-[0_0_16px_#f97316]',
  frame_diamond: 'ring-4 ring-cyan-300 shadow-[0_0_16px_#67e8f9]',
};
export const fmt = (n: number) => Math.floor(n || 0).toLocaleString('en-US');
export const fmtM = (m: number) => (m >= 100 ? Math.round(m) : m >= 10 ? m.toFixed(1) : m.toFixed(2)) + 'x';

export function Btn({ kind = 'gold', className = '', children, onClick, disabled, sound = true }: any) {
  return (
    <motion.button whileTap={{ scale: 0.94 }} disabled={disabled} onClick={(e: any) => { if (sound) sfx.click(); onClick && onClick(e); }}
      className={`btn-${kind} rounded-2xl px-4 py-3 text-base active:brightness-90 ${className}`}>{children}</motion.button>
  );
}
export function Header({ title, onBack, right }: any) {
  return (
    <div className="safe-top flex items-center gap-3 px-4 pb-2">
      <Btn kind="dark" className="!px-3 !py-2" onClick={onBack}>←</Btn>
      <div className="flex-1 text-xl font-black gold-text">{title}</div>{right}
    </div>
  );
}
export function Counter({ value, className = '' }: any) {
  const [v, setV] = useState(value); const from = useRef(value);
  useEffect(() => {
    const a = from.current, b = value, t0 = performance.now(); let raf = 0;
    const tick = (t: number) => { const p = Math.min(1, (t - t0) / 700); setV(Math.round(a + (b - a) * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(tick); else from.current = b; };
    raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf);
  }, [value]);
  return <span className={className}>{fmt(v)}</span>;
}
export function Wallet({ s }: any) {
  return (
    <div className="flex gap-2">
      <div className="glass flex items-center gap-1 px-3 py-1 font-extrabold"><span>🪙</span><Counter value={s.gold} className="text-yellow-300" /></div>
      <div className="glass flex items-center gap-1 px-3 py-1 font-extrabold"><span>💎</span><Counter value={s.diamonds} className="text-cyan-300" /></div>
    </div>
  );
}
export function Avatar({ s, size = 56 }: any) {
  return <div style={{ width: size, height: size, fontSize: size * 0.55 }} className={`flex items-center justify-center rounded-full bg-black/40 ${FRAMES[s.eq.frame] || FRAMES.frame_none}`}>{AVATARS[s.avatar] || '🐔'}</div>;
}
export function Toast({ t }: any) {
  if (!t) return null;
  return <motion.div initial={{ y: -40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} key={t.id}
    className={`pointer-events-none fixed left-1/2 top-4 z-[100] -translate-x-1/2 rounded-2xl px-5 py-3 text-center font-bold shadow-xl ${t.kind === 'error' ? 'bg-red-600' : t.kind === 'good' ? 'bg-emerald-600' : 'bg-violet-700'}`}>{t.msg}</motion.div>;
}
export function Modal({ children, onClose }: any) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-5" onClick={onClose}>
      <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="glass w-full max-w-sm p-5" style={{ background: 'rgba(25,10,50,.92)' }} onClick={(e: any) => e.stopPropagation()}>{children}</motion.div>
    </motion.div>
  );
}
