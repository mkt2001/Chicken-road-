// Chicken Road – Golden Run server. Authoritative game logic, auth, leaderboard, admin.
import express from 'express';
import cors from 'cors';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { DEFAULT_CONFIG } from '../shared/config.js';
import { newState, act, rollover, ACTION_NAMES } from '../shared/service.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
fs.mkdirSync(path.join(DATA_DIR, 'backups'), { recursive: true });

// ---------- storage (JSON file; schema for PostgreSQL is in server/schema.sql) ----------
let db = { users: {}, config: {}, secret: '', stats: { rounds: 0 } };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; } catch (e) { /* first run */ }
if (!db.secret) db.secret = crypto.randomBytes(32).toString('hex');
let timer = null;
function save() {
  clearTimeout(timer);
  timer = setTimeout(() => { try { fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db)); fs.renameSync(DB_FILE + '.tmp', DB_FILE); } catch (e) { console.error('save failed', e.message); } }, 400);
}
function backup() {
  try {
    fs.copyFileSync(DB_FILE, path.join(DATA_DIR, 'backups', 'db-' + Date.now() + '.json'));
    const files = fs.readdirSync(path.join(DATA_DIR, 'backups')).sort();
    while (files.length > 24) fs.unlinkSync(path.join(DATA_DIR, 'backups', files.shift()));
  } catch (e) { /* nothing to back up yet */ }
}
setInterval(backup, 3600000).unref();
const cfg = () => ({ ...DEFAULT_CONFIG, ...db.config });
const rng = () => crypto.randomInt(0, 4294967296) / 4294967296;

// ---------- auth ----------
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const sign = (p) => { const body = b64({ ...p, exp: Date.now() + 30 * 86400000 }); return body + '.' + crypto.createHmac('sha256', db.secret).update(body).digest('base64url'); };
function verify(tok) {
  if (!tok || !tok.includes('.')) return null;
  const [body, sig] = tok.split('.');
  const good = crypto.createHmac('sha256', db.secret).update(body).digest('base64url');
  if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString()); return p.exp > Date.now() ? p : null; } catch (e) { return null; }
}
const hashPw = (pw, salt = crypto.randomBytes(16).toString('hex')) => salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const checkPw = (pw, h) => { const [salt, x] = h.split(':'); return crypto.timingSafeEqual(Buffer.from(hashPw(pw, salt).split(':')[1], 'hex'), Buffer.from(x, 'hex')); };
function makeUser(id, name, extra = {}) {
  const u = { id, name, role: 'player', banned: false, created: Date.now(), friends: [], lastStep: 0, state: newState(cfg(), name), ...extra };
  db.users[id] = u; save(); return u;
}
const session = (u) => ({ token: sign({ id: u.id }), user: pub(u), state: u.state, config: cfg() });
const pub = (u) => ({ id: u.id, name: u.state.name, role: u.role, email: u.email || '' });
const auth = (req, res, next) => {
  const p = verify((req.headers.authorization || '').replace('Bearer ', ''));
  const u = p && db.users[p.id];
  if (!u) return res.status(401).json({ ok: false, error: 'Session expired. Please log in again.' });
  if (u.banned) return res.status(403).json({ ok: false, error: 'Account suspended' });
  req.user = u; next();
};
const admin = (req, res, next) => (req.user.role === 'admin' ? next() : res.status(403).json({ ok: false, error: 'Admin only' }));

const hits = new Map();
const limiter = (max, ms) => (req, res, next) => {
  const k = req.ip + req.path, now = Date.now(); const a = (hits.get(k) || []).filter((x) => now - x < ms);
  a.push(now); hits.set(k, a); if (a.length > max) return res.status(429).json({ ok: false, error: 'Too many requests' }); next();
};
setInterval(() => hits.clear(), 600000).unref();

const app = express();
app.use(cors()); app.use(express.json({ limit: '30kb' }));

app.post('/api/auth/guest', limiter(20, 60000), (req, res) => {
  const dev = String(req.body.deviceId || ''); if (dev.length < 8 || dev.length > 80) return res.status(400).json({ ok: false, error: 'Bad device id' });
  const id = 'g_' + crypto.createHash('sha256').update(dev).digest('hex').slice(0, 24);
  const u = db.users[id] || makeUser(id, 'Guest' + Math.floor(1000 + Math.random() * 9000));
  if (u.banned) return res.status(403).json({ ok: false, error: 'Account suspended' });
  res.json({ ok: true, ...session(u) });
});
app.post('/api/auth/register', limiter(10, 60000), (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase(), pw = String(req.body.password || '');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ ok: false, error: 'Invalid email' });
  if (pw.length < 6) return res.status(400).json({ ok: false, error: 'Password must be 6+ characters' });
  const id = 'e_' + crypto.createHash('sha256').update(email).digest('hex').slice(0, 24);
  if (db.users[id]) return res.status(409).json({ ok: false, error: 'Email already registered' });
  const name = String(req.body.name || email.split('@')[0]).replace(/[^\w \-]/g, '').slice(0, 16) || 'Player';
  res.json({ ok: true, ...session(makeUser(id, name, { email, pw: hashPw(pw) })) });
});
app.post('/api/auth/login', limiter(15, 60000), (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const u = db.users['e_' + crypto.createHash('sha256').update(email).digest('hex').slice(0, 24)];
  if (!u || !u.pw || !checkPw(String(req.body.password || ''), u.pw)) return res.status(401).json({ ok: false, error: 'Wrong email or password' });
  if (u.banned) return res.status(403).json({ ok: false, error: 'Account suspended' });
  res.json({ ok: true, ...session(u) });
});
app.post('/api/auth/google', limiter(10, 60000), async (req, res) => {
  const cid = process.env.GOOGLE_CLIENT_ID; if (!cid) return res.status(501).json({ ok: false, error: 'Google login is not configured on the server' });
  try {
    const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(String(req.body.idToken || '')));
    const g = await r.json(); if (!r.ok || g.aud !== cid) throw new Error('bad token');
    const id = 'gl_' + g.sub; const u = db.users[id] || makeUser(id, String(g.given_name || 'Player').slice(0, 16), { email: g.email });
    if (u.banned) return res.status(403).json({ ok: false, error: 'Account suspended' });
    res.json({ ok: true, ...session(u) });
  } catch (e) { res.status(401).json({ ok: false, error: 'Google sign-in failed' }); }
});
app.get('/api/config', (req, res) => res.json(cfg()));
app.get('/api/me', auth, (req, res) => { rollover(req.user.state, cfg(), Date.now()); res.json({ ok: true, user: pub(req.user), state: req.user.state, config: cfg() }); });

// All gameplay goes through here; the client never sends balances or multipliers.
app.post('/api/act', auth, limiter(600, 60000), (req, res) => {
  const { name, args } = req.body, u = req.user, now = Date.now();
  if (!ACTION_NAMES.includes(name)) return res.status(400).json({ ok: false, error: 'Unknown action' });
  if (name === 'stepRound') { if (now - u.lastStep < 250) return res.status(429).json({ ok: false, error: 'Too fast', state: u.state }); u.lastStep = now; }
  const r = act(u.state, cfg(), rng, name, args && typeof args === 'object' ? args : {}, now);
  if (name === 'startRound' && r.ok) db.stats.rounds++;
  if (name === 'setProfile' && r.ok) u.name = u.state.name;
  save(); res.json({ ...r, state: u.state });
});

function board(period, me) {
  const key = { global: ['bestMult', 'bestScore'], week: ['wMult', 'wScore'], month: ['mMult', 'mScore'], friends: ['bestMult', 'bestScore'] }[period] || ['bestMult', 'bestScore'];
  let list = Object.values(db.users).filter((u) => u.role === 'player' && !u.banned);
  if (period === 'friends') list = list.filter((u) => u.id === me.id || me.friends.includes(u.id));
  const rows = list.map((u) => {
    const s = u.state, g = period === 'global' || period === 'friends';
    return { id: u.id, name: s.name, avatar: s.avatar, frame: s.eq.frame, mult: g ? s.stats.bestMult : s.lb[key[0]], score: g ? s.stats.bestScore : s.lb[key[1]], crossings: s.stats.crossings, ap: s.lb.ap };
  }).filter((r) => r.mult > 0).sort((a, b) => b.mult - a.mult || b.score - a.score);
  return rows.slice(0, 50).map((r, i) => ({ ...r, rank: i + 1, me: r.id === me.id }));
}
app.get('/api/leaderboard', auth, (req, res) => { const me = req.user; rollover(me.state, cfg(), Date.now()); res.json({ ok: true, rows: board(String(req.query.period || 'global'), me) }); });
app.post('/api/friends/add', auth, (req, res) => {
  const n = String(req.body.name || '').trim().toLowerCase();
  const f = Object.values(db.users).find((u) => u.role === 'player' && u.state.name.toLowerCase() === n && u.id !== req.user.id);
  if (!f) return res.status(404).json({ ok: false, error: 'Player not found' });
  if (!req.user.friends.includes(f.id)) req.user.friends.push(f.id); save(); res.json({ ok: true });
});

// ---------- admin ----------
const A = [auth, admin];
app.get('/api/admin/stats', ...A, (req, res) => {
  const us = Object.values(db.users).filter((u) => u.role === 'player');
  res.json({ ok: true, players: us.length, rounds: db.stats.rounds, totalGold: us.reduce((a, u) => a + u.state.gold, 0), totalEarned: us.reduce((a, u) => a + u.state.stats.earned, 0), banned: us.filter((u) => u.banned).length });
});
app.get('/api/admin/players', ...A, (req, res) => res.json({ ok: true, rows: Object.values(db.users).map((u) => ({ id: u.id, name: u.state.name, email: u.email || '', role: u.role, gold: u.state.gold, diamonds: u.state.diamonds, games: u.state.stats.games, banned: u.banned, created: u.created })) }));
app.post('/api/admin/grant', ...A, (req, res) => {
  const u = db.users[req.body.id]; if (!u) return res.status(404).json({ ok: false, error: 'No such player' });
  const g = Math.floor(Number(req.body.gold) || 0), d = Math.floor(Number(req.body.diamonds) || 0);
  u.state.gold = Math.max(0, u.state.gold + g); u.state.diamonds = Math.max(0, u.state.diamonds + d);
  u.state.history.unshift({ t: Date.now(), type: 'admin', amount: g, cur: 'g', note: 'Admin adjustment', bal: u.state.gold }); save(); res.json({ ok: true });
});
app.post('/api/admin/ban', ...A, (req, res) => { const u = db.users[req.body.id]; if (!u || u.role === 'admin') return res.status(404).json({ ok: false, error: 'Cannot change this user' }); u.banned = !!req.body.banned; save(); res.json({ ok: true }); });
app.get('/api/admin/config', ...A, (req, res) => res.json({ ok: true, config: cfg() }));
app.put('/api/admin/config', ...A, (req, res) => {
  const { key, value } = req.body; if (!(key in DEFAULT_CONFIG) || key === 'version') return res.status(400).json({ ok: false, error: 'Unknown config key' });
  if (typeof value !== typeof DEFAULT_CONFIG[key] || Array.isArray(value) !== Array.isArray(DEFAULT_CONFIG[key])) return res.status(400).json({ ok: false, error: 'Wrong value type' });
  db.config[key] = value; save(); res.json({ ok: true, config: cfg() });
});
app.delete('/api/admin/config/:key', ...A, (req, res) => { delete db.config[req.params.key]; save(); res.json({ ok: true, config: cfg() }); });

// ---------- admin account + static site ----------
const AE = (process.env.ADMIN_EMAIL || 'admin@chickenroad.local').toLowerCase(), AP = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
const aid = 'e_' + crypto.createHash('sha256').update(AE).digest('hex').slice(0, 24);
if (!db.users[aid]) makeUser(aid, 'Admin', { email: AE, pw: hashPw(AP), role: 'admin' });
if (!process.env.ADMIN_PASSWORD) console.warn('[WARN] Using default admin password. Set ADMIN_EMAIL and ADMIN_PASSWORD env vars before deploying!');
const dist = path.join(__dirname, '..', 'dist');
if (fs.existsSync(dist)) { app.use(express.static(dist)); app.get(/^\/(?!api).*/, (req, res) => res.sendFile(path.join(dist, 'index.html'))); }
app.listen(PORT, () => console.log('Chicken Road server running on port ' + PORT));
