// Pure game math shared by client (offline mode) and server (authoritative mode).
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export function mulberry32(a) {
  return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
export function secureRandom() {
  const c = typeof globalThis !== 'undefined' ? globalThis.crypto : null;
  if (c && c.getRandomValues) { const a = new Uint32Array(1); c.getRandomValues(a); return a[0] / 4294967296; }
  return Math.random();
}
// 0..1 toughness of a level from speed, density, gaps, reaction time, patterns, moving obstacles, complexity.
export function difficultyScore(cfg, level) {
  const d = cfg.difficulties[clamp(level, 1, cfg.difficulties.length) - 1], w = cfg.weights;
  return clamp(w.speed * d.speed + w.density * d.density + w.gap * (1 - d.gap) + w.reaction * (1 - d.reaction) +
    w.pattern * d.pattern + w.moving * d.moving + w.complexity * d.complexity, 0, 1);
}
// Probability of being hit when stepping onto lane number `step+1`.
export function hazard(cfg, level, step, mode) {
  const h = cfg.hazard, m = cfg.modes[mode] || cfg.modes.classic;
  const base = h.base + h.scale * Math.pow(difficultyScore(cfg, level), h.power);
  return clamp(base * (1 + h.ramp * step) * m.risk, h.min, h.max);
}
// Multiplier ladder: payout = RTP / survival probability, so tougher levels pay more.
export function multTable(cfg, level, mode, lanes) {
  const out = []; let surv = 1, prev = 1;
  for (let k = 0; k < lanes; k++) {
    surv *= 1 - hazard(cfg, level, k, mode);
    let m = Math.min(cfg.rtp / surv, cfg.maxMult);
    m = Math.max(m, prev + 0.01, 1.01);
    m = Math.round(m * 100) / 100; out.push(m); prev = m;
  }
  return out;
}
export function hazardTable(cfg, level, mode, lanes) {
  return Array.from({ length: lanes }, (_, k) => hazard(cfg, level, k, mode));
}
// Visual traffic pattern for a lane. Always keeps at least one gap wide enough to hop through.
export function lanePattern(cfg, level, k, seed) {
  const d = cfg.difficulties[clamp(level, 1, 10) - 1];
  const r = mulberry32((seed || 1) * 7919 + k * 104729 + level * 13);
  const speed = 3.5 + d.speed * 10 * (0.8 + r() * 0.4);
  const period = 48;
  let n = clamp(Math.round(1 + d.density * 3 * (0.7 + r() * 0.6)), 1, 4);
  const minGap = speed * (0.7 + (1 - d.reaction) * 0.9) + 6;
  while (n > 1 && period / n < minGap) n--;
  const base = period / n, types = ['car', 'car', 'bike', 'truck', 'bus'], vehicles = [];
  for (let i = 0; i < n; i++) {
    const tp = types[Math.floor(r() * (2 + Math.min(3, Math.floor(d.complexity * 3) + 1))) % 5];
    vehicles.push({ type: tp, off: i * base + (r() - 0.5) * Math.max(0, base - minGap) * 0.8, hue: Math.floor(r() * 360) });
  }
  return { dir: k % 2 ? 1 : -1, speed, period, vehicles, gap: Math.round(base), moving: d.moving };
}
