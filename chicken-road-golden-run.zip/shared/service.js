// Game rules as pure functions over a player "state". Runs offline on the client and authoritatively on the server.
import { multTable, hazard, clamp } from './engine.js';

export const dayKey = (t) => new Date(t).toISOString().slice(0, 10);
export const weekKey = (t) => Math.floor((Math.floor(t / 86400000) + 3) / 7);
export const monthKey = (t) => new Date(t).toISOString().slice(0, 7);
export function dailyLevel(cfg, t) {
  let h = 0; for (const ch of dayKey(t)) h = (h * 31 + ch.charCodeAt(0)) % 100003;
  return clamp(cfg.modes.daily.minLevel + (h % (11 - cfg.modes.daily.minLevel)), 1, 10);
}
export function newState(cfg, name = 'Player') {
  return {
    v: 1, name, avatar: 0, gold: cfg.startGold, diamonds: cfg.startDiamonds, history: [],
    stats: { games: 0, wins: 0, losses: 0, earned: 0, bestMult: 0, bestScore: 0, crossings: 0, streak: 0, bestStreak: 0 },
    owned: ['skin_classic', 'road_city', 'bg_dusk', 'anim_hop', 'sfx_classic', 'fx_sparkle', 'frame_none'],
    eq: { skin: 'skin_classic', road: 'road_city', bg: 'bg_dusk', anim: 'anim_hop', sfx: 'sfx_classic', fx: 'fx_sparkle', frame: 'frame_none' },
    daily: { streak: 0, last: '' }, mis: { day: '', week: -1, p: {}, c: {}, bonusDay: '' }, ach: {}, round: null,
    wheel: '', refill: 0, dailyChallenge: '',
    lb: { wk: -1, wMult: 0, wScore: 0, mo: '', mMult: 0, mScore: 0, ap: 0 },
    settings: { music: true, sfx: true, vol: 0.7, quality: 'auto' },
  };
}
const fail = (error) => ({ ok: false, error });
function addHist(s, type, amount, cur, note, t) {
  s.history.unshift({ t, type, amount, cur, note, bal: cur === 'd' ? s.diamonds : s.gold });
  if (s.history.length > 150) s.history.length = 150;
}
function credit(s, amt, note, t, cur = 'g') {
  amt = Math.floor(amt); if (!(amt > 0)) return 0;
  if (cur === 'g') { s.gold += amt; s.stats.earned += amt; } else s.diamonds += amt;
  addHist(s, 'credit', amt, cur, note, t); return amt;
}
function debit(s, amt, note, t, cur = 'g') {
  amt = Math.floor(amt); const key = cur === 'g' ? 'gold' : 'diamonds';
  if (!(amt >= 0) || s[key] < amt) return false;
  s[key] -= amt; if (amt > 0) addHist(s, 'debit', -amt, cur, note, t); return true;
}
export function rollover(s, cfg, t) {
  const d = dayKey(t), w = weekKey(t), m = monthKey(t);
  if (s.mis.day !== d) { s.mis.day = d; for (const x of cfg.missions) if (x.type === 'daily') { delete s.mis.p[x.id]; delete s.mis.c[x.id]; } }
  if (s.mis.week !== w) { s.mis.week = w; for (const x of cfg.missions) if (x.type === 'weekly') { delete s.mis.p[x.id]; delete s.mis.c[x.id]; } }
  if (s.lb.wk !== w) { s.lb.wk = w; s.lb.wMult = 0; s.lb.wScore = 0; }
  if (s.lb.mo !== m) { s.lb.mo = m; s.lb.mMult = 0; s.lb.mScore = 0; }
}
function bump(s, cfg, stat, amount, mode) {
  for (const m of cfg.missions) {
    if (m.stat !== stat || (m.mode && m.mode !== mode)) continue;
    s.mis.p[m.id] = stat === 'maxmult' ? Math.max(s.mis.p[m.id] || 0, amount) : (s.mis.p[m.id] || 0) + amount;
  }
}
function checkAch(s, cfg, t) {
  for (const a of cfg.achievements) {
    if (s.ach[a.id]) continue;
    const v = a.stat === 'gold' ? s.gold : a.stat === 'owned' ? s.owned.length : s.stats[a.stat];
    if (v >= a.target) { s.ach[a.id] = t; credit(s, a.gold || 500, 'Achievement: ' + a.title, t); s.lb.ap += a.pts || 10; }
  }
}
const evBonus = (cfg, n) => (cfg.event && cfg.event.active ? Math.floor(n * (1 + cfg.event.pct / 100)) : n);

function claimDaily(s, cfg, rng, a, t) {
  const d = dayKey(t);
  if (s.daily.last === d) return fail('Already claimed today');
  const streak = s.daily.last === dayKey(t - 86400000) ? s.daily.streak + 1 : 1;
  const idx = (streak - 1) % cfg.daily.length;
  const amount = credit(s, evBonus(cfg, cfg.daily[idx]), 'Daily reward day ' + (idx + 1), t);
  if (idx === cfg.daily.length - 1) credit(s, cfg.dailyDiamondsDay7 || 0, 'Weekly streak bonus', t, 'd');
  s.daily = { streak, last: d }; checkAch(s, cfg, t);
  return { ok: true, amount, day: idx + 1 };
}
function startRound(s, cfg, rng, a, t) {
  if (s.round && s.round.status === 'active') return fail('A round is already active');
  const m = cfg.modes[a.mode]; if (!m) return fail('Unknown mode');
  const level = a.mode === 'daily' ? dailyLevel(cfg, t) : clamp(Math.round(a.level) || 1, m.minLevel || 1, cfg.difficulties.length);
  const stake = Math.floor(a.stake);
  if (!(stake >= cfg.minStake)) return fail('Minimum stake is ' + cfg.minStake);
  if (stake > cfg.maxStake) return fail('Maximum stake is ' + cfg.maxStake);
  if (s.gold < stake) return fail('Not enough coins');
  debit(s, stake, 'Round stake', t);
  s.round = { id: Math.floor(rng() * 1e9).toString(36) + t.toString(36), mode: a.mode, level, stake, lanes: m.lanes, step: 0, mult: 1,
    status: 'active', start: t, deadline: m.timer ? t + m.timer * 1000 : 0, seed: 1 + Math.floor(rng() * 1e6) };
  return { ok: true, round: s.round };
}
function finishLoss(s, cfg, r, status, t) {
  r.status = status; s.stats.games++; s.stats.losses++; s.stats.streak = 0;
  bump(s, cfg, 'rounds', 1, r.mode); checkAch(s, cfg, t);
}
function doCashout(s, cfg, r, t, auto) {
  const m = cfg.modes[r.mode];
  const payout = Math.floor(r.stake * r.mult), profit = payout - r.stake;
  credit(s, payout, 'Cash out ' + r.mult.toFixed(2) + 'x', t);
  r.status = 'cashed'; r.payout = payout; r.profit = profit; r.auto = !!auto;
  const score = Math.round(r.mult * 100) + r.step * 50; r.score = score;
  const st = s.stats; st.games++; st.wins++; st.streak++; st.bestStreak = Math.max(st.bestStreak, st.streak);
  st.bestMult = Math.max(st.bestMult, r.mult); st.bestScore = Math.max(st.bestScore, score);
  s.lb.wMult = Math.max(s.lb.wMult, r.mult); s.lb.mMult = Math.max(s.lb.mMult, r.mult);
  s.lb.wScore = Math.max(s.lb.wScore, score); s.lb.mScore = Math.max(s.lb.mScore, score);
  bump(s, cfg, 'rounds', 1, r.mode); bump(s, cfg, 'wins', 1, r.mode); bump(s, cfg, 'maxmult', r.mult, r.mode);
  r.bonus = {};
  if (r.step >= r.lanes && m.bonusDiamonds) { credit(s, m.bonusDiamonds, 'Full crossing bonus', t, 'd'); r.bonus.diamonds = m.bonusDiamonds; }
  if (r.mode === 'daily' && s.dailyChallenge !== dayKey(t)) {
    s.dailyChallenge = dayKey(t); r.bonus.gold = credit(s, m.dailyReward || 300, 'Daily challenge reward', t);
  }
  checkAch(s, cfg, t);
}
function stepRound(s, cfg, rng, a, t) {
  const r = s.round; if (!r || r.status !== 'active') return fail('No active round');
  if (r.deadline && t > r.deadline + 1500) { finishLoss(s, cfg, r, 'timeout', t); return { ok: true, hit: true, timeout: true, round: r }; }
  if (r.step >= r.lanes) return fail('Already at the finish');
  const hit = rng() < hazard(cfg, r.level, r.step, r.mode);
  if (hit) { finishLoss(s, cfg, r, 'lost', t); return { ok: true, hit: true, round: r }; }
  r.step++; r.mult = multTable(cfg, r.level, r.mode, r.lanes)[r.step - 1];
  s.stats.crossings++; bump(s, cfg, 'crossings', 1, r.mode);
  const done = r.step >= r.lanes && cfg.modes[r.mode].auto;
  if (done) doCashout(s, cfg, r, t, true); else checkAch(s, cfg, t);
  return { ok: true, hit: false, done, round: r };
}
function cashout(s, cfg, rng, a, t) {
  const r = s.round; if (!r || r.status !== 'active') return fail('No active round');
  if (r.step < 1) return fail('Cross at least one lane first');
  if (r.deadline && t > r.deadline + 1500) { finishLoss(s, cfg, r, 'timeout', t); return { ok: true, timeout: true, round: r }; }
  doCashout(s, cfg, r, t, false);
  return { ok: true, round: r };
}
function expire(s, cfg, rng, a, t) {
  const r = s.round;
  if (!r || r.status !== 'active' || !r.deadline || t < r.deadline) return fail('Nothing to expire');
  finishLoss(s, cfg, r, 'timeout', t); return { ok: true, round: r };
}
function clearRound(s) { if (s.round && s.round.status !== 'active') s.round = null; return { ok: true }; }
function buy(s, cfg, rng, a, t) {
  const it = cfg.items.find((x) => x.id === a.id); if (!it) return fail('Unknown item');
  if (s.owned.includes(it.id)) return fail('Already owned');
  if (it.diamonds > 0) { if (!debit(s, it.diamonds, 'Bought ' + it.name, t, 'd')) return fail('Not enough diamonds'); }
  else if (!debit(s, it.gold, 'Bought ' + it.name, t)) return fail('Not enough coins');
  s.owned.push(it.id); s.eq[it.cat] = it.id; checkAch(s, cfg, t); return { ok: true, item: it };
}
function equip(s, cfg, rng, a) {
  const it = cfg.items.find((x) => x.id === a.id); if (!it || !s.owned.includes(it.id)) return fail('Item not owned');
  s.eq[it.cat] = it.id; return { ok: true };
}
const pick = (list, rng) => { let n = rng() * list.reduce((q, x) => q + x.w, 0); for (const x of list) { n -= x.w; if (n < 0) return x; } return list[list.length - 1]; };
function spin(s, cfg, rng, a, t) {
  const d = dayKey(t), free = s.wheel !== d;
  if (!free && !debit(s, cfg.wheelCost, 'Lucky wheel spin', t)) return fail('Not enough coins');
  if (free) s.wheel = d;
  const seg = pick(cfg.wheel, rng), index = cfg.wheel.indexOf(seg);
  if (seg.g) credit(s, evBonus(cfg, seg.g), 'Lucky wheel', t);
  if (seg.d) credit(s, seg.d, 'Lucky wheel', t, 'd');
  checkAch(s, cfg, t); return { ok: true, index, seg, free };
}
function openBox(s, cfg, rng, a, t) {
  if (!debit(s, cfg.boxCost, 'Mystery box', t)) return fail('Not enough coins');
  const loot = pick(cfg.box, rng); let res;
  if (loot.t === 'g') { const n = loot.min + Math.floor(rng() * (loot.max - loot.min + 1)); credit(s, n, 'Mystery box', t); res = { gold: n }; }
  else if (loot.t === 'd') { const n = loot.min + Math.floor(rng() * (loot.max - loot.min + 1)); credit(s, n, 'Mystery box', t, 'd'); res = { diamonds: n }; }
  else {
    const pool = cfg.items.filter((x) => !s.owned.includes(x.id) && !(x.diamonds > 0) && x.gold <= 5000);
    if (pool.length) { const it = pool[Math.floor(rng() * pool.length)]; s.owned.push(it.id); res = { item: it }; addHist(s, 'credit', 0, 'g', 'Mystery box item: ' + it.name, t); }
    else { credit(s, 1000, 'Mystery box', t); res = { gold: 1000 }; }
  }
  checkAch(s, cfg, t); return { ok: true, res };
}
function exchange(s, cfg, rng, a, t) {
  const q = Math.floor(a.qty); if (!(q > 0) || q > 100000) return fail('Invalid amount');
  if (a.dir === 'toDiamonds') {
    if (!debit(s, q * cfg.exchange.goldPerDiamond, 'Exchange to diamonds', t)) return fail('Not enough coins');
    credit(s, q, 'Exchange', t, 'd');
  } else {
    if (!debit(s, q, 'Exchange to coins', t, 'd')) return fail('Not enough diamonds');
    credit(s, q * cfg.exchange.diamondToGold, 'Exchange', t);
  }
  return { ok: true };
}
function claimMission(s, cfg, rng, a, t) {
  const m = cfg.missions.find((x) => x.id === a.id); if (!m) return fail('Unknown mission');
  if (s.mis.c[m.id]) return fail('Already claimed');
  if ((s.mis.p[m.id] || 0) < m.target) return fail('Mission not complete');
  s.mis.c[m.id] = true; credit(s, m.gold, 'Mission: ' + m.title, t); if (m.diamonds) credit(s, m.diamonds, 'Mission: ' + m.title, t, 'd');
  let bonus = 0; const dailies = cfg.missions.filter((x) => x.type === 'daily');
  if (dailies.filter((x) => s.mis.c[x.id]).length >= 5 && s.mis.bonusDay !== dayKey(t)) {
    s.mis.bonusDay = dayKey(t); bonus = credit(s, cfg.missionBonus, 'Completed 5 missions', t);
  }
  return { ok: true, bonus };
}
function refill(s, cfg, rng, a, t) {
  const r = cfg.refill;
  if (s.gold >= r.below) return fail('Only available when you have under ' + r.below + ' coins');
  const wait = r.hours * 3600000 - (t - s.refill);
  if (wait > 0) return fail('Available in ' + Math.ceil(wait / 60000) + ' min');
  s.refill = t; credit(s, r.amount, 'Free refill', t); return { ok: true };
}
function setProfile(s, cfg, rng, a) {
  const name = String(a.name || '').replace(/[^\w \-]/g, '').trim().slice(0, 16);
  if (name.length < 2) return fail('Name must be 2-16 letters');
  s.name = name; s.avatar = clamp(Math.floor(a.avatar) || 0, 0, 7); return { ok: true };
}
function setSettings(s, cfg, rng, a) {
  const o = s.settings;
  if (typeof a.music === 'boolean') o.music = a.music;
  if (typeof a.sfx === 'boolean') o.sfx = a.sfx;
  if (typeof a.vol === 'number') o.vol = clamp(a.vol, 0, 1);
  if (['auto', 'low', 'medium', 'high'].includes(a.quality)) o.quality = a.quality;
  return { ok: true };
}
const ACTIONS = { claimDaily, startRound, stepRound, cashout, expire, clearRound, buy, equip, spin, openBox, exchange, claimMission, refill, setProfile, setSettings };
export const ACTION_NAMES = Object.keys(ACTIONS);
export function act(s, cfg, rng, name, args, t) {
  const f = ACTIONS[name]; if (!f) return fail('Unknown action');
  t = t || Date.now(); rollover(s, cfg, t);
  const res = f(s, cfg, rng, args || {}, t);
  if (s.gold < 0) s.gold = 0; if (s.diamonds < 0) s.diamonds = 0;
  return res;
}
