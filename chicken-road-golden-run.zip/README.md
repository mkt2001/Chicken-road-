# 🐔 Chicken Road – Golden Run
Premium 3D multiplier arcade game. **Virtual coins only** – no real money, no deposits, no withdrawals.

React + TypeScript + Three.js (React Three Fiber, Drei) + Tailwind + Framer Motion · Node/Express server · Capacitor Android APK.

## Two ways to run
| Mode | How | What you get |
|---|---|---|
| **Offline (default)** | no setup | Full game on the device, progress saved locally. Best for the APK. |
| **Server mode** | build with `VITE_REMOTE=1` | Guest/Email/Google login, server-validated coins & rewards (anti-cheat), cloud save, global/weekly/monthly/friends leaderboards, Admin dashboard. |

## Folder structure
```
shared/    engine.js (difficulty + multiplier math), service.js (ALL game rules), config.js (defaults)
server/    index.js (Express API), schema.sql (PostgreSQL/Supabase schema)
src/       App.tsx, store.ts, audio.ts, ui.tsx
src/game/  Scene.tsx (3D world), Game.tsx (HUD + gameplay flow)
src/screens/ Menus.tsx, Auth.tsx, Admin.tsx
.github/workflows/build.yml   builds web + debug APK on GitHub
```
The same `shared/service.js` runs on the phone (offline) and on the server (authoritative), so rules never differ.

## Install & develop
```bash
npm install
npm run dev                      # offline game at http://localhost:5173
# server mode:
ADMIN_EMAIL=you@mail.com ADMIN_PASSWORD=StrongPass1 npm run server      # API on :8080
VITE_REMOTE=1 npm run dev        # game talks to /api (proxied to :8080)
```
## Build
```bash
npm run build                    # web build in dist/
VITE_REMOTE=1 npm run build && npm start     # one server serves site + API on :8080
```
## Android APK (GitHub Actions – no PC needed)
1. Upload all project files to a GitHub repo (see below) and push to `main`.
2. Open **Actions → Build Web + Android APK → Run workflow** (it also runs on every push).
3. When it finishes, download the artifact **ChickenRoad-GoldenRun-APK** → `app-debug.apk` → install.

Local build: `npm run build && npx cap add android && npx cap sync android && cd android && ./gradlew assembleDebug` (needs JDK 17 + Android SDK).
For online mode in the APK, add repository variables/secrets as env in the workflow build step: `VITE_REMOTE=1` and `VITE_API_URL=https://your-server`.

## Deploy the server
* **Docker**: `docker build -t chicken-road . && docker run -p 8080:8080 -v crdata:/data -e ADMIN_EMAIL=... -e ADMIN_PASSWORD=... chicken-road`
* **Render / Railway / Fly**: build command `npm install && VITE_REMOTE=1 npm run build`, start command `npm start`, add a persistent disk and set `DATA_DIR` to it.
* Env vars: `PORT`, `DATA_DIR`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` (**change the default!**), `GOOGLE_CLIENT_ID` (server) + `VITE_GOOGLE_CLIENT_ID` (client build) for Google login.
* Data is stored in `DATA_DIR/db.json` with hourly rotating backups (`backups/`). `server/schema.sql` is the PostgreSQL/Supabase schema if you move to a SQL database.

## Admin dashboard
Server mode → log in with the admin email/password → Settings → **Admin Dashboard** (or open `/#/admin`).
Players (grant coins, ban), live stats, and a config editor for difficulty table, multiplier engine (`rtp`, `hazard`, `weights`), modes, rewards, missions, wheel, shop prices, events – no code changes needed.

## How difficulty → multiplier works
Each of the 10 levels defines speed, density, safe-gap, reaction time, pattern, moving-obstacle and complexity values. They are weighted into a 0–1 **difficulty score**; that sets the hit probability per lane (growing with each lane and by mode risk). Multiplier = `RTP ÷ survival probability`, so harder roads always pay more. Outcomes are rolled by the game logic (server in online mode); the 3D traffic is drawn to match the result and always keeps a hop-sized gap in generated patterns.

## Features checklist
6 modes · 10 difficulty levels · live multiplier/risk/reward HUD · cash out (duplicate-safe, never negative balance) · 9 chicken skins + shop (skins, 7 road themes, menu backgrounds, hop animations, sound packs, trails, frames) · daily login streak · lucky wheel · mystery box · daily/weekly missions · 10 achievements · coin shop (gold ⇄ diamonds) · wallet history · leaderboards · profile & stats · VIP collection · events · music/SFX/volume · auto graphics quality · save & resume.
