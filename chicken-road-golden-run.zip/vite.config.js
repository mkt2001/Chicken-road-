import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  plugins: [react()],
  base: './',
  build: { chunkSizeWarningLimit: 4000 },
  server: { host: true, proxy: { '/api': 'http://localhost:8080' } },
});
